<?php
$conn = new mysqli("localhost", "root", "", "dental"); // Connect to DB

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$query = "SELECT amount FROM billing WHERE bill_id = 1"; // Replace with the actual bill_id value
$result = $conn->query($query); // Execute query
if ($result && $row = $result->fetch_assoc()) {
    $price = $row['amount'];
} else {
    $price = 0; // Default to 0 if not found
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dental Clinic Booking</title> 
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background-color: white;
            text-align: center;
            position: relative;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .btn-custom {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border-radius: 10px;
            text-decoration: none;
            border: none;
            font-weight: bold;
            transition: 0.3s;
        }

        .btn-custom:hover {
            background-color: #0056b3;
        }

        .btn-about {
            position: absolute;
            top: 20px;
            left: 20px;
        }

        .btn-auth {
            position: absolute;
            top: 20px;
            right: 20px;
        }

        .btn-auth .btn-custom {
            margin-left: 10px;
        }

        .btn-meeting {
            margin-top: 20px;
        }

        h2 {
            font-family: Arial, sans-serif;
            font-weight: bold;
            margin-top: 50px;
        }
        
        
   


        /* Flip Card Styling */
        .flip-card {
            width: 280px;
            height: 400px;
            perspective: 1000px;
        }

        .flip-card-inner {
            position: relative;
            width: 100%;
            height: 100%;
            transform-style: preserve-3d;
            transition: transform 0.6s;
        }

        .flip-card.flipped .flip-card-inner {
            transform: rotateY(180deg);
        }

        .flip-card-front, .flip-card-back {
            position: absolute;
            width: 100%;
            height: 100%;
            backface-visibility: hidden;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            background: white;
        }

        .flip-card-back {
            transform: rotateY(180deg);
            display: flex;
            justify-content: center;
            align-items: center;
            font-weight: bold;
            color: #007bff;
        }

        .card img {
            width: 100%;
            height: 250px;
            object-fit: cover;
            border-radius: 10px 10px 0 0;
        }
    </style>
</head>
<body>
<button class="btn-custom btn-about" onclick="location.href='aboutus.php'">About Us</button>

    <div class="btn-auth">
        <button class="btn-custom" onclick="location.href='login.php'">Log in</button>
        <button class="btn-custom" onclick="location.href ='signup.php'">Sign Up</button>
    </div>

    <h2>DENTAL CLINIC BOOKING WEBSITE</h2>

    <!-- Cards Section -->
    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-3">
                <div class="flip-card" onclick="flipCard(this)">
                    <div class="flip-card-inner">
                        <div class="flip-card-front card">
                            <img src="img/pediatric.jpg" class="card-img-top" alt="Pediatric Dentistry">
                            <div class="card-body">
                                <h5 class="card-title">Pediatric Dentistry</h5>
                                <p class="card-text">Price: ₱10<?php echo number_format($price, 2); ?></p>
                            </div>
                        </div>
                        <div class="flip-card-back">More Details</div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="flip-card" onclick="flipCard(this)">
                    <div class="flip-card-inner">
                        <div class="flip-card-front card">
                            <img src="img/3.jpg" class="card-img-top" alt="Cosmetic Dentistry">
                            <div class="card-body">
                                <h5 class="card-title">Cosmetic Dentistry</h5>
                                <p class="card-text">Price: ₱20<?php echo number_format($price, 2); ?></p>
                            </div>
                        </div>
                        <div class="flip-card-back">More Details</div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="flip-card" onclick="flipCard(this)">
                    <div class="flip-card-inner">
                        <div class="flip-card-front card">
                            <img src="img/2.jpeg" class="card-img-top" alt="Restorative Treatment">
                            <div class="card-body">
                                <h5 class="card-title">Restorative Treatment</h5>
                                <p class="card-text">Price: ₱50<?php echo number_format($price, 2); ?></p>
                            </div>
                        </div>
                        <div class="flip-card-back">More Details</div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="flip-card" onclick="flipCard(this)">
                    <div class="flip-card-inner">
                        <div class="flip-card-front card">
                            <img src="img/1.jpeg" class="card-img-top" alt="Routine & Preventive Care">
                            <div class="card-body">
                                <h5 class="card-title">Routine & Preventive Care</h5>
                                <p class="card-text">Price: ₱100<?php echo number_format($price, 2); ?></p>

                            </div>
                        </div>
                        <div class="flip-card-back">
                            Space Maintainers are devices used in pediatric dentistry. They hold space for permanent teeth after premature loss of baby teeth.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <button class="btn-custom btn-meeting" onclick="location.href='login.php'">SCHEDULE APPOINTMENT</button>

    <script>
        function flipCard(card) {
            card.classList.toggle("flipped");
        }
    </script>
</body>
</html>
