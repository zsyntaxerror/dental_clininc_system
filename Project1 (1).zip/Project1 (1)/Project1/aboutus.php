<?php
$conn = new mysqli("localhost", "root", "", "dental"); // Connect to DB
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Dental Clinic</title> 
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background-color: white;
            text-align: center;
            position: relative;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .btn-custom {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border-radius: 10px;
            text-decoration: none;
            border: none;
            font-weight: bold;
            transition: 0.3s;
        }

        .btn-custom:hover {
            background-color: #0056b3;
        }

        .btn-home {
            position: absolute;
            top: 20px;
            left: 20px;
        }

        .btn-auth {
            position: absolute;
            top: 20px;
            right: 20px;
        }

        .btn-auth .btn-custom {
            margin-left: 10px;
        }

        h2 {
            font-family: Arial, sans-serif;
            font-weight: bold;
            margin-top: 80px;
            margin-bottom: 40px;
        }

        .about-section {
            max-width: 1000px;
            margin: 0 auto;
            padding: 20px;
            text-align: left;
        }

        .team-member {
            margin-bottom: 30px;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            background: white;
            transition: transform 0.3s;
            height: 100%;
        }

        .team-member:hover {
            transform: translateY(-5px);
        }

        .team-img {
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 50%;
            margin-bottom: 15px;
        }

        .mission-vision {
            display: flex;
            justify-content: space-between;
            margin-top: 40px;
            margin-bottom: 40px;
        }

        .mission, .vision {
            flex: 1;
            margin: 0 15px;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            background: white;
            height: 100%;
        }

        .section-title {
            color: #007bff;
            margin-bottom: 20px;
            font-weight: bold;
        }

        .footer {
            background-color: #f8f9fa;
            padding: 20px 0;
            margin-top: auto;
        }

        @media (max-width: 768px) {
            .mission-vision {
                flex-direction: column;
            }
            
            .mission, .vision {
                margin: 15px 0;
            }
            
            .team-row {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <button class="btn-custom btn-home" onclick="location.href='index.php'">Home</button>

    <div class="btn-auth">
        <button class="btn-custom" onclick="location.href='login.php'">Log in</button>
        <button class="btn-custom" onclick="location.href ='signup.php'">Sign Up</button>
    </div>

    <h2>ABOUT OUR DENTAL CLINIC</h2>

    <div class="container about-section">
        <div class="row mb-5">
            <div class="col-12">
                <h3 class="section-title">Welcome to Our Dental Practice</h3>
                <p>Our dental clinic has been committed to providing exceptional dental care to patients of all ages. With state-of-the-art technology and a compassionate team of dental professionals, we strive to create a comfortable and welcoming environment where patients can receive the highest quality of dental services.</p>
                <p>We offer a comprehensive range of dental services including pediatric dentistry, cosmetic dentistry, restorative treatments, and routine & preventive care. Our team is dedicated to helping you achieve and maintain optimal oral health through personalized treatment plans tailored to your specific needs.</p>
            </div>
        </div>

        <div class="mission-vision">
            <div class="mission">
                <h4 class="section-title">Our Mission</h4>
                <p>To provide exceptional dental care in a comfortable and welcoming environment, utilizing the latest technologies and techniques to ensure optimal oral health for all our patients.</p>
            </div>
            <div class="vision">
                <h4 class="section-title">Our Vision</h4>
                <p>To be the leading dental practice known for excellence in patient care, innovative treatments, and creating beautiful, healthy smiles that last a lifetime.</p>
            </div>
        </div>

        <h3 class="section-title mt-5">Meet Our Team</h3>
        <div class="row">
            <div class="col-md-3">
                <div class="team-member">
                    <img src="../Project1/img/8.jpg" alt="John Philip Baloro" class="team-img">
                    <h5>John Philip Baloro</h5>
                    <p>Programmer</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="team-member">
                    <img src="../Project1/img/10.jpg" alt="Hanz Earl Tan" class="team-img">
                    <h5>Hanz Earl Tan</h5>
                    <p>Project Manager</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="team-member">
                    <img src="../Project1/img/9.jpg" alt="Khen Adora" class="team-img">
                    <h5>Khen Adora</h5>
                    <p>Lead Programmer</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="team-member">
                    <img src="../Project1/img/11.jpg" alt="Trisha Lim" class="team-img">
                    <h5>Trisha Lim</h5>
                    <p>Data Analyst</p>
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-12">
                <h3 class="section-title">Our Facility</h3>
                <p>Our modern dental clinic is equipped with the latest technology to provide you with the best possible care. We maintain strict sterilization protocols and follow all health and safety guidelines to ensure a clean and safe environment for our patients and staff.</p>
            </div>
        </div>

        <div class="row mt-4 mb-5">
            <div class="col-md-6">
                <div class="team-member">
                    <h4>Location</h4>
                    <p>Capt.Vicente. Roa St<br>Cagayan De Oro, Philippines</p>
                    <p>Open Monday to Saturday<br>8:00 AM - 5:00 PM</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="team-member">
                    <h4>Contact Us</h4>
                    <p>Phone: 09319529199</p>
                    <p>Email: info@dentalclinic.com</p>
                    <p>For appointments, call us or schedule online!</p>
                </div>
            </div>
        </div>
    </div>

    <div class="footer">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <p>© 2025 Dental Clinic. All rights reserved.</p>
                </div>
            </div>
        </div>
    </div>

</body>
</html>