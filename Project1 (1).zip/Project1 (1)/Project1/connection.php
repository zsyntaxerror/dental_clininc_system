<?php
$database = new mysqli("localhost", "root", "", "dental");

if ($database->connect_error) {
    die("Connection failed: " . $database->connect_error);
}

$result = $database->query("SELECT * FROM dental.users");

if ($result->num_rows == 0) {
    die("Error: Table 'users' does not exist in the database.");
} else {
    // echo "Table 'users' exists!";
}

?>
