<?php
session_start();
include("connection.php");

// Only process the form submission if it's a POST request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Siguraduhin na may session data
    if (!isset($_SESSION['personal'])) {
        die("Session data missing. Please complete the previous form.");
    }

    // Kunin ang session data
    $p_name = $_SESSION['personal']['fname'] . " " . $_SESSION['personal']['lname']; // Pagsamahin ang fname at lname
    $p_address = $_SESSION['personal']['address'];
    $dob = $_SESSION['personal']['dob'];
    $p_gender = $_POST['gender']; // Galing sa form
    $p_contact = $_POST['contact']; // Galing sa form
    $p_email = $_POST['newemail']; // Galing sa form
    $p_password = password_hash($_POST['newpassword'], PASSWORD_BCRYPT); // Encrypt password

    // Compute age from DOB
    $birthDate = new DateTime($dob);
    $today = new DateTime();
    $age = $today->diff($birthDate)->y; // Kinukuha ang edad mula DOB

    // I-check kung may existing email na
    $check_query = "SELECT * FROM patients WHERE p_email = '$p_email'";
    $result = mysqli_query($database, $check_query);

    if (mysqli_num_rows($result) > 0) {
        $error = "Email already exists. Please use a different email.";
    } else {
        // I-insert ang data sa `patients` table
        $insert_query = "INSERT INTO patients (p_name, p_age, p_gender, p_contact, p_email, p_password, p_address, p_dob) 
                        VALUES ('$p_name', '$age', '$p_gender', '$p_contact', '$p_email', '$p_password', '$p_address', '$dob')";
        $insert_user = $database->query("INSERT INTO users (username,role) VALUES ('$p_name','p')");


        if (mysqli_query($database, $insert_query)) {
            echo "Account successfully created!";
            unset($_SESSION["personal"]); // Clear session after successful registration
            header("Location: login.php"); // Redirect to login page
            exit();
        } else {
            $error = "Error inserting data: " . mysqli_error($database);
        }
    }

    mysqli_close($database);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</head>
<body class="d-flex justify-content-center align-items-center vh-100 bg-light">   
    <div class="container d-flex justify-content-center align-items-center vh-100">
    <div class="card p-5 shadow-lg" style="width: 800px;">
    <img src="img/teeth.jpg" alt="" class="img-fluid" style="max-width: 200px; height: auto">
    <div class="text-center">
    <h2 class="text-info-black">Let's Get Started</h2>
        </div>
         <p class="text-center">Creat Your Account</p>


          <form action="create_account.php" method="POST">
      
               <label for="newemail" class="form-label">Email</label>
                <input type="email" name="newemail" class="form-control mb-3" placeholder="Email Address" required>
       
                <label for="gender" class="form-label">Gender </label></td>
                <select name="gender" class="form-control mb-3" required>
                <option value="">Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
            </select>
       
                <label for="contact" class="form-label">Mobile Number: </label></td>
                  <input type="tel" name="contact" class="form-control mb-3" placeholder="ex: 09123456789" pattern="09[0-9]{9}" required>
       
                  <label for="newpassword" class="form-label">Create Password: </label></td>
                     <input type="password" name="newpassword" class="form-control mb-3" placeholder="New Password" required>
           
                <label for="cpassword" class="form-label">Confirm Password: </label></td>
                    <input type="password" name="cpassword" class="form-control mb-3" placeholder="Confirm Password" required>
            
           <?php echo isset($error) ? $error : ''; ?>
       
        
            <input type="submit" value="Sign Up" class=" btn btn-primary w-100 mt-3"></td>
                       
                <div class="text-center mt-3">
                    <label class="sub-text">Already have an account? </label>
                    <a href="login.php" class="hover-link1 non-style-link">Login</a>
                </div>
</form>
    </div>
</body>
</html>