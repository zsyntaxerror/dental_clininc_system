<?php
session_start();

// Redirect to login if the user is not logged in or not a patient
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'patient') {
    header("Location: login.php");
    exit();
}

// Establish database connection
$conn = new mysqli('localhost', 'root', '', 'dental');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $appointmentType = $_POST['appointment_type'];
    $subService = $_POST['sub_service'];
    $appointmentDate = $_POST['appointment_date'];
    $appointmentTime = $_POST['appointment_time'];
    $patientId = $_SESSION['patient_id'] ?? 1; // Assuming you have patient_id stored in the session

    // Validate input (you can add more validation as needed)
    if (!empty($appointmentType) && !empty($subService) && !empty($appointmentDate) && !empty($appointmentTime)) {
        // Prepare and bind
        $stmt = $conn->prepare("INSERT INTO appointments (p_id, doc_id, p_type, date, time) VALUES (?, ?, ?, ?, ?)");
        
        // Fetch doctor id based on the selected service (you can adjust this logic based on your database structure)
        // Assuming "doc_id" is determined by the service type (you might have your logic here)
        $docId = getDoctorIdByService($subService); // You should implement this function based on your application's logic.

        $stmt->bind_param("iisss", $patientId, $docId, $appointmentType, $appointmentDate, $appointmentTime);

        // Execute the statement
        if ($stmt->execute()) {
            // Appointment scheduled successfully
            $_SESSION['message'] = "Appointment scheduled successfully!";
            header("Location: bookings.php");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Please complete all fields.";
    }
}

$conn->close();

function getDoctorIdByService($subService) {
    // Implement your logic here to return the doctor ID based on the selected sub-service
    // Example: return $docId;
    return 1; // Placeholder, replace with actual logic for fetching doctor ID based on service type.
}
?>