<?php
session_start();
include '../client/connection.php';

// Check if user is logged in
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

// Initialize variables for filtering
$filter_date = '';
$filter_doctor = '';
$search_term = '';

// Handle search functionality
if (isset($_POST['search'])) {
    $search_term = $_POST['search_term'];
}

// Handle filter functionality
if (isset($_POST['filter'])) {
    $filter_date = $_POST['filter_date'] ?? '';
    $filter_doctor = $_POST['filter_doctor'] ?? '';
}

// Query to fetch doctors for the dropdown
$doctors_query = "SELECT doc_id, doc_name FROM doctors";
$doctors_result = $conn->query($doctors_query);
$doctors = [];
if ($doctors_result && $doctors_result->num_rows > 0) {
    while($row = $doctors_result->fetch_assoc()) {
        $doctors[$row['doc_id']] = $row['doc_name'];
    }
}

// Base query for appointments
$query = "SELECT a.app_id, a.p_type, d.doc_id, d.doc_name, p.p_id, p.p_name, a.date, a.time, a.status 
          FROM appointments a 
          INNER JOIN doctors d ON a.doc_id = d.doc_id 
          INNER JOIN patients p ON a.p_id = p.p_id";

// Add filters if set
$where_conditions = [];
if (!empty($search_term)) {
    $search_term = $conn->real_escape_string($search_term);
    $where_conditions[] = "(d.doc_name LIKE '%$search_term%' OR d.doc_email LIKE '%$search_term%' OR p.p_name LIKE '%$search_term%' OR a.p_type LIKE '%$search_term%')";
}
if (!empty($filter_date)) {
    $where_conditions[] = "a.date = '$filter_date'";
}
if (!empty($filter_doctor)) {
    $where_conditions[] = "a.doc_id = $filter_doctor";
}

// Append where conditions to query
if (!empty($where_conditions)) {
    $query .= " WHERE " . implode(' AND ', $where_conditions);
}

// Execute the query
$result = $conn->query($query);

// Process status update if needed
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Handle Approve action
    if (isset($_POST['approve']) && isset($_POST['appointment_id'])) {
        $appointmentId = $_POST['appointment_id'];
        
        $update_query = "UPDATE appointments SET status = 'Scheduled' WHERE app_id = ?";
        $stmt = $conn->prepare($update_query);
        $stmt->bind_param("i", $appointmentId);
        
        if ($stmt->execute()) {
            $_SESSION['success_message'] = "Appointment approved successfully!";
            header("Location: Appointment.php");
            exit();
        } else {
            $_SESSION['error_message'] = "Error updating status: " . $stmt->error;
        }
        
        $stmt->close();
    }
    
    // Handle Done/Complete action
    if (isset($_POST['done']) && isset($_POST['appointment_id'])) {
        $appointmentId = $_POST['appointment_id'];
        
        $update_query = "UPDATE appointments SET status = 'Completed' WHERE app_id = ?";
        $stmt = $conn->prepare($update_query);
        $stmt->bind_param("i", $appointmentId);
        
        if ($stmt->execute()) {
            $_SESSION['success_message'] = "Appointment marked as completed!";
            header("Location: Appointment.php");
            exit();
        } else {
            $_SESSION['error_message'] = "Error updating status: " . $stmt->error;
        }
        
        $stmt->close();
    }
    
    // Handle Cancel action
    if (isset($_POST['cancel']) && isset($_POST['appointment_id'])) {
        $appointmentId = $_POST['appointment_id'];
        
        $update_query = "UPDATE appointments SET status = 'Cancelled' WHERE app_id = ?";
        $stmt = $conn->prepare($update_query);
        $stmt->bind_param("i", $appointmentId);
        
        if ($stmt->execute()) {
            $_SESSION['success_message'] = "Appointment cancelled!";
            header("Location: Appointment.php");
            exit();
        } else {
            $_SESSION['error_message'] = "Error updating status: " . $stmt->error;
        }
        
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Schedule Manager</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <style>
         * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
             }

        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 300px;
            height: 100vh;
            background: white;
            padding: 20px;
            box-shadow: 2px 0px 5px rgba(0, 0, 0, 0.1);
            position: fixed;
        }

        .sidebar h3 {
            text-align: center;
            font-weight: bold;
        }

        .sidebar p {
            font-size: 14px;
            color: gray;
        }

        .sidebar a {
            display: block;
            width: 100%;
            padding: 10px;
            text-align: center;
            text-decoration: none;
            color: black;
            font-weight: bold;
            border-radius: 5px;
            transition: background 0.3s ease;
        }

        .sidebar a:hover {
            background: #e9ecef;
        }

        .sidebar .nav-link {
            color: black;
            font-size: 16px;
        }

        .sidebar .nav-link.active {
            color: #0d6efd;
            font-weight: bold;
        }

        .sidebar button {
            background-color: #0d6efd;
            border: none;
            color: white;
            font-size: 16px;
        }

        .sidebar button:hover {
            background-color: #0b5ed7;
        }

        /* Main Content Styling */
        .content-container {
            width: calc(100% - 300px);
            margin-left: 300px;
            padding: 20px;
        }

        /* Search and Filter Styling */
        .search-box {
            margin-bottom: 1rem;
        }

        .search-field {
            border-radius: 4px;
            border: 1px solid #ced4da;
            padding: 0.5rem 1rem;
            width: 100%;
        }

        .search-button {
            border-radius: 4px;
            background-color: #0d6efd;
            color: white;
            border: none;
            padding: 0.5rem 1rem;
        }

        /* Filter Buttons */
        .filter-button {
            background-color: #0d6efd;
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 4px;
        }

        /* Action Buttons */
        .btn-approve {
            background-color: #198754;
            color: white;
        }

        .btn-done {
            background-color: #0d6efd;
            color: white;
        }

        .btn-cancel {
            background-color: #dc3545;
            color: white;
        }

        /* Status Badges */
        .badge {
            font-size: 14px;
            padding: 8px 12px;
            border-radius: 4px;
        }

        .badge-completed {
            background-color: #198754;
            color: white;
        }

        .badge-scheduled {
            background-color: #0d6efd;
            color: white;
        }

        .badge-pending {
            background-color: #ffc107;
            color: black;
        }

        .badge-cancelled {
            background-color: #dc3545;
            color: white;
        }

        /* Table Styling */
        .appointment-table {
            border-collapse: collapse;
            width: 100%;
        }

        .appointment-table th {
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            padding: 12px 15px;
            text-align: center;
        }

        .appointment-table td {
            border: 1px solid #dee2e6;
            padding: 12px 15px;
            text-align: center;
        }

        /* Add New Button */
        .btn-add-new {
            background-color: #0d6efd;
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 4px;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body class="bg-light d-flex">
    <!-- Sidebar -->
<nav class="bg-white p-3 shadow-sm vh-100" style="width: 300px; position: fixed;">
    <div class="text-center mb-4">
        <img src="../img/teeth.jpg" alt="" class="w-50">
        <h5 class="fw-bold mt-2">WELCOME!</h5>
        <?php echo isset($_SESSION['user']) ? htmlspecialchars($_SESSION['user']) : 'No email found'; ?>       
    </div>
    <button class="btn btn-primary w-100 mb-3" onclick="location.href='../index.php'">Log out</button>
    <ul class="nav flex-column">
        <li class="nav-item"><a href="dashboard.php" class="nav-link text-black">Dashboard</a></li>
        <li class="nav-item"><a href="Doctors.php" class="nav-link text-black">Dentist</a></li>
        <li class="nav-item"><a href="schedule.php" class="nav-link text-black">Schedule</a></li>
        <li class="nav-item"><a href="Appointment.php" class="nav-link text-black active">Appointment</a></li>
        <li class="nav-item"><a href="patient.php" class="nav-link text-black">Patients</a></li>
    </ul>
</nav>
   

    <!-- Main Content -->
     <!-- Main Content -->
<main class="content-container" style="margin-left: 300px; width: calc(100% - 300px);">
    <!-- Status Messages -->
    <?php if(isset($_SESSION['success_message'])): ?>
        <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
            <?php 
                echo $_SESSION['success_message']; 
                unset($_SESSION['success_message']);
            ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <?php if(isset($_SESSION['error_message'])): ?>
        <div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
            <?php 
                echo $_SESSION['error_message']; 
                unset($_SESSION['error_message']);
            ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Search Box -->
    <div class="row mt-3">
        <div class="col-12">
            <form method="post" action="">
                <div class="input-group mb-3">
                    <input type="text" name="search_term" class="form-control" placeholder="Search Doctor name or Email" value="<?php echo htmlspecialchars($search_term); ?>">
                    <button class="btn btn-primary" type="submit" name="search">Search</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Appointment Manager Title -->
    <h2 class="mb-3">Appointment Manager</h2>
    
    <!-- Add New Button -->
    <a href="add_appointment.php" class="btn btn-primary mb-3">+ Add New</a>
    
    <!-- All Sessions Text -->
    <p class="lead">All Sessions</p>
    
    <!-- Filters -->
    <form method="post" action="" class="mb-4">
        <div class="row g-3 align-items-end">
            <div class="col-md-4">
                <label class="form-label">Date:</label>
                <input type="date" name="filter_date" class="form-control" value="<?php echo htmlspecialchars($filter_date); ?>">
            </div>
            <div class="col-md-5">
                <label class="form-label">Doctor:</label>
                <select name="filter_doctor" class="form-select">
                    <option value="">All Dentists</option>
                    <?php foreach($doctors as $id => $name): ?>
                        <option value="<?php echo $id; ?>" <?php echo $filter_doctor == $id ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($name); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <button type="submit" name="filter" class="btn btn-primary w-100">Filter</button>
            </div>
        </div>
    </form>
    
    <!-- Appointments Table -->
    <div class="table-responsive">
        <table class="table table-bordered appointment-table">
            <thead>
                <tr>
                    <th>Patient Name</th>
                    <th>Appointment Number</th>
                    <th>Dentist</th>
                    <th>Appointment Date</th>
                    <th>Type of Appointment</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                if ($result && $result->num_rows > 0) {
                    $appointment_number = $result->num_rows; // Start with total number
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['p_name']) . "</td>";
                        echo "<td>" . $appointment_number-- . "</td>"; // Decrement for each row
                        echo "<td>" . htmlspecialchars($row['doc_name']) . "</td>"; // Removed "Dr." prefix
                        echo "<td>" . htmlspecialchars($row['date']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['p_type']) . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5' class='text-center'>No appointments found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</main>
   
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>