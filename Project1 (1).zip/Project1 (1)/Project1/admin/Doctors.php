<?php
session_start();

$conn = new mysqli('localhost', 'root', '', 'dental');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Add dentist
if (isset($_POST['action']) && $_POST['action'] == 'add_dentist') {
    $name = $conn->real_escape_string($_POST['dentistName']);
    $email = $conn->real_escape_string($_POST['dentistEmail']);
    $gender = $conn->real_escape_string($_POST['dentistGender']);
    $contact = $conn->real_escape_string($_POST['dentistContact']);
    $specialtyId = $conn->real_escape_string($_POST['dentistSpecialty']);
    
    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Invalid email format";
    } else {
        // Check if email is already in use
        $checkEmailQuery = "SELECT doc_id FROM doctors WHERE doc_email = '$email'";
        $checkResult = $conn->query($checkEmailQuery);
        
        if ($checkResult->num_rows > 0) {
            $error_message = "Email already in use";
        } else {
            // Insert new dentist
            $sql = "INSERT INTO doctors (doc_name, doc_email, doc_gender, doc_contact, specialty_id) 
                    VALUES ('$name', '$email', '$gender', '$contact', '$specialtyId')";
            
            if ($conn->query($sql) === TRUE) {
                $success_message = "Dentist added successfully";
            } else {
                $error_message = "Error adding dentist: " . $conn->error;
            }
        }
    }
}

// Update dentist
if (isset($_POST['action']) && $_POST['action'] == 'update_dentist') {
    $dentistId = $conn->real_escape_string($_POST['dentistId']);
    $name = $conn->real_escape_string($_POST['dentistName']);
    $email = $conn->real_escape_string($_POST['dentistEmail']);
    $gender = $conn->real_escape_string($_POST['dentistGender']);
    $contact = $conn->real_escape_string($_POST['dentistContact']);
    $specialtyId = $conn->real_escape_string($_POST['dentistSpecialty']);
    
    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Invalid email format";
    } else {
        // Check if email is already in use by another dentist
        $checkEmailQuery = "SELECT doc_id FROM doctors WHERE doc_email = '$email' AND doc_id != '$dentistId'";
        $checkResult = $conn->query($checkEmailQuery);
        
        if ($checkResult->num_rows > 0) {
            $error_message = "Email already in use by another dentist";
        } else {
            // Update dentist
            $sql = "UPDATE doctors SET 
                    doc_name = '$name', 
                    doc_email = '$email', 
                    doc_gender = '$gender', 
                    doc_contact = '$contact', 
                    specialty_id = '$specialtyId' 
                    WHERE doc_id = '$dentistId'";
            
            if ($conn->query($sql) === TRUE) {
                $success_message = "Dentist updated successfully";
            } else {
                $error_message = "Error updating dentist: " . $conn->error;
            }
        }
    }
}
    
// Delete dentist
if (isset($_POST['action']) && $_POST['action'] == 'delete_dentist') {
    $dentistId = $conn->real_escape_string($_POST['dentistId']);
    
    $sql = "DELETE FROM doctors WHERE doc_id = '$dentistId'";
    
    if ($conn->query($sql) === TRUE) {
        $success_message = "Dentist removed successfully";
    } else {
        $error_message = "Error removing dentist: " . $conn->error;
    }
}

// Fetch dentists from the database with specialty names
$sql = "SELECT d.doc_id, d.doc_name, d.doc_email, d.doc_gender, d.doc_contact, s.specialty_name, d.specialty_id
        FROM doctors d 
        LEFT JOIN specialties s ON d.specialty_id = s.specialty_id";
$result = $conn->query($sql);

$dentists = []; // Initialize an empty array to avoid "undefined variable"
if ($result && $result->num_rows > 0) {
    // Fetching results into an associative array
    while ($row = $result->fetch_assoc()) {
        $dentists[] = $row; // Add each dentist to the array
    }
}

// Fetch specialties for the dropdown
$specialtiesQuery = "SELECT specialty_id, specialty_name FROM specialties ORDER BY specialty_name";
$specialtiesResult = $conn->query($specialtiesQuery);

$specialties = [];
if ($specialtiesResult && $specialtiesResult->num_rows > 0) {
    while ($row = $specialtiesResult->fetch_assoc()) {
        $specialties[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="css/doctors.css">
</head>
<body class="bg-light d-flex">
<nav class="bg-white p-3 shadow-sm vh-100" style="width: 300px; position: fixed;">
    <div class="text-center mb-4">
        <img src="../img/teeth.jpg" alt="" class="w-50">
        <h5 class="fw-bold mt-2">WELCOME!</h5>
        <?php echo isset($_SESSION['user']) ? htmlspecialchars($_SESSION['user']) : 'No email found'; ?>     
    </div>
    <button class="btn btn-primary w-100 mb-3" onclick="location.href='logout.php'">Log out</button>
    <ul class="nav flex-column">
        <li class="nav-item"><a href="dashboard.php" class="nav-link text-black">Dashboard</a></li>
        <li class="nav-item"><a href="Doctors.php" class="nav-link text-black">Dentist</a></li>
        <li class="nav-item"><a href="schedule.php" class="nav-link text-black">Schedule</a></li>
        <li class="nav-item"><a href="Appointment.php" class="nav-link text-black">Appointment</a></li>
        <li class="nav-item"><a href="patient.php" class="nav-link text-black">Patients</a></li>
    </ul>
</nav>
    
<div class="content container-fluid" style="margin-left: 320px; padding-top: 20px;">
    <div class="d-flex justify-content-between align-items-center">
        <input type="text" class="form-control me-2" placeholder="Search Doctor name or Email">
        <button id="search" class="btn btn-primary w-30">Search</button>
    </div>
    
    <?php if (isset($error_message)): ?>
    <div class="alert alert-danger mt-3"><?php echo $error_message; ?></div>
    <?php endif; ?>
    
    <?php if (isset($success_message)): ?>
    <div class="alert alert-success mt-3"><?php echo $success_message; ?></div>
    <?php endif; ?>
    
    <h4 class="fw-bold mt-3">Add New Dentist</h4>
    <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addDentistModal">+ Add New</button>
    
    <!-- Add Dentist Modal -->
    <div class="modal fade" id="addDentistModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Dentist</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="addDentistForm" method="post" action="">
                        <input type="hidden" name="action" value="add_dentist">
                        <div class="mb-3">
                            <label for="addDentistName" class="form-label">Name</label>
                            <input type="text" class="form-control" id="addDentistName" name="dentistName" required>
                        </div>
                        <div class="mb-3">
                            <label for="addDentistEmail" class="form-label">Email</label>
                            <input type="email" class="form-control" id="addDentistEmail" name="dentistEmail" required>
                        </div>
                        <div class="mb-3">
                            <label for="addDentistGender" class="form-label">Gender</label>
                            <select class="form-select" id="addDentistGender" name="dentistGender" required>
                                <option value="">Select Gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="addDentistContact" class="form-label">Contact Number</label>
                            <input type="text" class="form-control" id="addDentistContact" name="dentistContact" required>
                        </div>
                        <div class="mb-3">
                            <label for="addDentistSpecialty" class="form-label">Specialty</label>
                            <select class="form-select" id="addDentistSpecialty" name="dentistSpecialty" required>
                                <option value="">Select Specialty</option>
                                <?php foreach ($specialties as $specialty): ?>
                                <option value="<?php echo $specialty['specialty_id']; ?>">
                                    <?php echo htmlspecialchars($specialty['specialty_name']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Add Dentist</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Edit Dentist Modal - THIS WAS MISSING -->
    <div class="modal fade" id="editDentistModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Dentist</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="editDentistForm" method="post" action="">
                        <input type="hidden" name="action" value="update_dentist">
                        <input type="hidden" id="editDentistId" name="dentistId">
                        <div class="mb-3">
                            <label for="editDentistName" class="form-label">Name</label>
                            <input type="text" class="form-control" id="editDentistName" name="dentistName" required>
                        </div>
                        <div class="mb-3">
                            <label for="editDentistEmail" class="form-label">Email</label>
                            <input type="email" class="form-control" id="editDentistEmail" name="dentistEmail" required>
                        </div>
                        <div class="mb-3">
                            <label for="editDentistGender" class="form-label">Gender</label>
                            <select class="form-select" id="editDentistGender" name="dentistGender" required>
                                <option value="">Select Gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="editDentistContact" class="form-label">Contact Number</label>
                            <input type="text" class="form-control" id="editDentistContact" name="dentistContact" required>
                        </div>
                        <div class="mb-3">
                            <label for="editDentistSpecialty" class="form-label">Specialty</label>
                            <select class="form-select" id="editDentistSpecialty" name="dentistSpecialty" required>
                                <option value="">Select Specialty</option>
                                <?php foreach ($specialties as $specialty): ?>
                                <option value="<?php echo $specialty['specialty_id']; ?>">
                                    <?php echo htmlspecialchars($specialty['specialty_name']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Update Dentist</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <!-- View Dentist Modal -->
    <div class="modal fade" id="viewDentistModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">View Dentist Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row mb-3">
                        <div class="col-4 fw-bold">Name:</div>
                        <div class="col-8" id="viewDentistName"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-4 fw-bold">Email:</div>
                        <div class="col-8" id="viewDentistEmail"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-4 fw-bold">Gender:</div>
                        <div class="col-8" id="viewDentistGender"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-4 fw-bold">Contact:</div>
                        <div class="col-8" id="viewDentistContact"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-4 fw-bold">Specialty:</div>
                        <div class="col-8" id="viewDentistSpecialty"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
        
    <div class="table-container mt-3">
        <table class="table table-bordered">
            <thead class="table-light">
                <tr>
                    <th>Dentist Name</th>
                    <th>Email</th>
                    <th>Gender</th>
                    <th>Contact</th>
                    <th>Specialties</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="dentistTableBody">
                <?php foreach ($dentists as $doctor): ?>
                <tr>
                    <td><?php echo htmlspecialchars($doctor['doc_name'] ?? 'N/A'); ?></td>
                    <td><?php echo htmlspecialchars($doctor['doc_email'] ?? 'N/A'); ?></td>
                    <td><?php echo htmlspecialchars($doctor['doc_gender'] ?? 'N/A'); ?></td>
                    <td><?php echo htmlspecialchars($doctor['doc_contact'] ?? 'N/A'); ?></td>
                    <td><?php echo htmlspecialchars($doctor['specialty_name'] ?? 'Not Assigned'); ?></td>
                    <td>
                        <button class="btn btn-sm btn-warning" onclick="editDentist(
                            '<?php echo $doctor['doc_id']; ?>', 
                            '<?php echo htmlspecialchars($doctor['doc_name']); ?>', 
                            '<?php echo htmlspecialchars($doctor['doc_email']); ?>', 
                            '<?php echo htmlspecialchars($doctor['doc_gender']); ?>', 
                            '<?php echo htmlspecialchars($doctor['doc_contact']); ?>', 
                            '<?php echo $doctor['specialty_id'] ?? ''; ?>'
                        )">Edit</button>
                        
                        <button class="btn btn-sm btn-info" onclick="viewDentist(
                            '<?php echo htmlspecialchars($doctor['doc_name']); ?>', 
                            '<?php echo htmlspecialchars($doctor['doc_email']); ?>', 
                            '<?php echo htmlspecialchars($doctor['doc_gender']); ?>', 
                            '<?php echo htmlspecialchars($doctor['doc_contact']); ?>', 
                            '<?php echo htmlspecialchars($doctor['specialty_name'] ?? 'Not Assigned'); ?>'
                        )">View</button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
// Function to handle modal close on successful form submission
document.addEventListener('DOMContentLoaded', function() {
    <?php if (isset($success_message)): ?>
    // Close the modal if it exists and is open
    var addModal = bootstrap.Modal.getInstance(document.getElementById('addDentistModal'));
    if (addModal) {
        addModal.hide();
    }
    
    var editModal = bootstrap.Modal.getInstance(document.getElementById('editDentistModal'));
    if (editModal) {
        editModal.hide();
    }
    <?php endif; ?>
});

function editDentist(id, name, email, gender, contact, specialtyId) {
    console.log("Edit button clicked for:", name);
    
    // Set the values in the edit form
    document.getElementById('editDentistId').value = id;
    document.getElementById('editDentistName').value = name;
    document.getElementById('editDentistEmail').value = email;
    document.getElementById('editDentistGender').value = gender;
    document.getElementById('editDentistContact').value = contact;
    document.getElementById('editDentistSpecialty').value = specialtyId;
    
    // Show the modal
    const modal = new bootstrap.Modal(document.getElementById('editDentistModal'));
    modal.show();
}

function viewDentist(name, email, gender, contact, specialty) {
    console.log("View button clicked for:", name);
    
    // Set the values in the view modal
    document.getElementById('viewDentistName').textContent = name;
    document.getElementById('viewDentistEmail').textContent = email;
    document.getElementById('viewDentistGender').textContent = gender;
    document.getElementById('viewDentistContact').textContent = contact;
    document.getElementById('viewDentistSpecialty').textContent = specialty;
    
    // Show the modal
    const modal = new bootstrap.Modal(document.getElementById('viewDentistModal'));
    modal.show();
}
</script>

</body>
</html>