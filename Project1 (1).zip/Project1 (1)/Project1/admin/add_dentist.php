<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_email'])) {
    header('Location: login.php');
    exit();
}

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Connect to database
    $conn = new mysqli('localhost', 'root', '', 'dental');
    
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    // Get form data and sanitize
    $name = $conn->real_escape_string($_POST['dentistName']);
    $email = $conn->real_escape_string($_POST['dentistEmail']);
    $specialtyId = $conn->real_escape_string($_POST['dentistSpecialty']);
    
    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email format";
        exit();
    }
    
    // Check if email is already in use
    $checkEmailQuery = "SELECT doc_id FROM doctors WHERE doc_email = '$email'";
    $checkResult = $conn->query($checkEmailQuery);
    
    if ($checkResult->num_rows > 0) {
        echo "Email already in use";
        exit();
    }
    
    // Insert new dentists
    $sql = "INSERT INTO doctors (doc_name, doc_email, specialty_id) VALUES ('$name', '$email', '$specialtyId')";
    
    if ($conn->query($sql) === TRUE) {
        echo "Dentist added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    $conn->close();
} else {
    // Not a POST request
    echo "Invalid request method";
}
?>