<?php
header('Content-Type: application/json');

$conn = new mysqli('localhost', 'root', '', 'admin_system');

if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Database connection failed"]));
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Debugging log
    error_log("Received DELETE request with ID: " . ($_POST['id'] ?? 'NONE'));

    if (!isset($_POST['id']) || empty($_POST['id'])) {
        echo json_encode(["success" => false, "message" => "No ID received"]);
        exit;
    }

    $id = intval($_POST['id']);

    if ($id <= 0) {
        echo json_encode(["success" => false, "message" => "Invalid ID"]);
        exit;
    }

    $query = "DELETE FROM dentists WHERE id = $id";
    if ($conn->query($query) === TRUE) {
        echo json_encode(["success" => true, "message" => "Dentist removed"]);
    } else {
        echo json_encode(["success" => false, "message" => "Error: " . $conn->error]);
    }
} else {
    echo json_encode(["success" => false, "message" => "Invalid request"]);
}

$conn->close();
?>
