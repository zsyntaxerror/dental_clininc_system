<?php
session_start();
include 'db.php'; // Database connection file

// Check if the remove action is triggered
if (isset($_GET['remove']) && !empty($_GET['remove'])) {
    $app_id = mysqli_real_escape_string($conn, $_GET['remove']);
    
    // Execute the delete query directly
    $delete_query = "DELETE FROM appointments WHERE app_id = '$app_id'";
    if (mysqli_query($conn, $delete_query)) {
        echo "<script>alert('Appointment removed successfully!');</script>";
    } else {
        echo "<script>alert('Error removing appointment: " . mysqli_error($conn) . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Manager</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/patient.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            width: 280px;
            background-color: #ffffff;
            min-height: 100vh;
            padding: 20px;
            border-right: 1px solid #dee2e6;
        }
        .sidebar h3 {
            text-align: center;
            font-weight: bold;
        }
        .sidebar .nav-link {
            color: black;
            font-size: 16px;
        }
        .sidebar .nav-link.active {
            color: #0d6efd;
            font-weight: bold;
        }
        .sidebar button {
            background-color: #0d6efd;
            border: none;
            color: white;
            font-size: 16px;
        }
        .sidebar button:hover {
            background-color: #0b5ed7;
        }
        .content {
            flex-grow: 1;
            padding: 40px;
            width: calc(100% - 280px);
        }
        .search-bar {
            width: 100%;
            background-color: #ffffff;
            border: 1px solid #ced4da;
            padding: 10px;
            font-size: 16px;
            border-radius: 5px;
        }
        .table th {
            border-bottom: 2px solid #0d6efd;
            font-size: 16px;
        }
        .table td {
            font-size: 14px;
        }
        .btn-primary {
            background-color: #0d6efd;
            border: none;
            font-size: 14px;
            padding: 8px 16px;
        }
        .btn-primary:hover {
            background-color: #0b5ed7;
        }
        .btn-danger {
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="d-flex">
    <nav class="bg-white p-3 shadow-sm vh-100" style="width: 300px; position: fixed;">
    <div class="text-center mb-4">
        <img src="../img/teeth.jpg" alt="" class="w-50">
        <h5 class="fw-bold mt-2">WELCOME!</h5>
        <?php echo isset($_SESSION['user']) ? htmlspecialchars($_SESSION['user']) : 'No email found'; ?>       
    </div>
    <button class="btn btn-primary w-100 mb-3" onclick="location.href='logout.php'">Log out</button>
    <ul class="nav flex-column">
        <li class="nav-item"><a href="dashboard.php" class="nav-link text-black">Dashboard</a></li>
        <li class="nav-item"><a href="Doctors.php" class="nav-link text-black">Dentist</a></li>
        <li class="nav-item"><a href="schedule.php" class="nav-link text-black">Schedule</a></li>
        <li class="nav-item"><a href="Appointment.php" class="nav-link text-black">Appointment</a></li>
        <li class="nav-item"><a href="patient.php" class="nav-link text-black">Patients</a></li>
    </ul>
</nav>

        <main class="content" style="margin-left: 300px;"> <!-- Adjusted margin to ensure content is visible -->
        <div class="d-flex justify-content-between align-items-center">
        <input type="text" class="form-control me-2" placeholder="Search Doctor name or Email">
            <button class="btn btn-primary w-30">Search</button>
        </div>
            <h2 class="mt-4">Patient Manager</h2>
            <p>All Patient</p>
            <div class="d-flex">
    <label class="me-2">Date:</label>
    <input type="date" class="form-control me-2" id="appointmentDate">
    <label class="me-2">Doctor:</label>
    <select class="form-select" id="doctorSelect">
        <option selected value="">Choose Doctor Name from the list</option>
        <option value="1">Dr. Smith</option>
        <option value="2">Dr. Johnson</option>
        <option value="3">Dr. Williams</option>
        <option value="4">Dr. Brown</option>
    </select>
    <button class="btn btn-primary ms-2" onclick="filterAppointments()">Filter</button>
</div>

<script>
function filterAppointments() {
    // Get the selected date value
    const selectedDate = document.getElementById('appointmentDate').value;
    
    // Get the selected doctor value
    const selectedDoctor = document.getElementById('doctorSelect').value;
    
    // Validate if any filter is selected
    if (!selectedDate && !selectedDoctor) {
        alert('Please select at least one filter criteria');
        return;
    }
    
    // Log the filter criteria (replace with actual filtering logic)
    console.log('Filtering appointments with the following criteria:');
    if (selectedDate) {
        console.log('Date:', selectedDate);
    }
    if (selectedDoctor) {
        console.log('Doctor ID:', selectedDoctor);
    }
    
    // Placeholder for demonstration
    alert(`Filter applied for Date: ${selectedDate || 'Any'}, Doctor: ${getSelectedDoctorName() || 'Any'}`);
}

function getSelectedDoctorName() {
    const select = document.getElementById('doctorSelect');
    if (select.value) {
        return select.options[select.selectedIndex].text;
    }
    return '';
}

function confirmRemove(id) {
    if (confirm('Are you sure you want to remove this patient appointment?')) {
        window.location.href = 'patient.php?remove=' + id;
    }
}
</script>
    <table class="table">
        <thead>
        <tr>
            <th>Patient Name</th>
            <th>Appointment_No</th>
            <th>Mobile No</th>
            <th>Email</th>
            <th>Date of Birth</th>
            <th>Booking Date</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>

        <?php
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null; // Ensure user_id is set
if (!$user_id) {
    $query = "SELECT p.p_name AS patient_name, a.app_id AS appointment_no, p.p_contact AS mobile, p.p_email AS email, p.p_dob AS date_of_birth, a.date AS booking_date 
              FROM appointments a 
              JOIN patients p ON a.p_id = p.p_id"; // Adjust column names to match your database schema
} else {
    $query = "SELECT p.p_name AS patient_name, a.app_id AS appointment_no, p.p_contact AS mobile, p.p_email AS email, p.p_dob AS date_of_birth, a.date AS booking_date 
              FROM appointments a 
              JOIN patients p ON a.p_id = p.p_id 
              WHERE p.p_id = $user_id"; // Adjust column names to match your database schema
}


$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $appointmentId = $row['appointment_no'];
        echo "<tr>";
        echo "<td>" . (isset($row['patient_name']) ? htmlspecialchars($row['patient_name']) : 'N/A') . "</td>";
        echo "<td>" . (isset($appointmentId) ? htmlspecialchars($appointmentId) : 'N/A') . "</td>";
        echo "<td>" . (isset($row['mobile']) ? htmlspecialchars($row['mobile']) : 'N/A') . "</td>";
        echo "<td>" . (isset($row['email']) ? htmlspecialchars($row['email']) : 'N/A') . "</td>";
        echo "<td>" . (isset($row['date_of_birth']) ? htmlspecialchars($row['date_of_birth']) : 'N/A') . "</td>";
        echo "<td>" . (isset($row['booking_date']) ? htmlspecialchars($row['booking_date']) : 'N/A') . "</td>";
        echo "<td>
                <button class='btn btn-danger btn-sm' onclick='confirmRemove(\"" . $appointmentId . "\")'>Remove</button>
              </td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='7' class='text-center'>No booking history found.</td></tr>";
}
?>
    </tbody>
</table>
</main>
</div>
</body>
</html>