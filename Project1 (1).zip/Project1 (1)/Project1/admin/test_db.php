<?php
include 'db.php';
if ($conn) {
    echo "Database connected successfully!";
}
?>
