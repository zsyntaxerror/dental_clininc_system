<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['name'];  // Assuming 'name' is the username
    $email = $_POST['email'];    // Unused, unless needed for verification
    $password = $_POST['password'];
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $role = "patient"; // Default role

    // Insert user into database
    $query = "INSERT INTO users (username, password, role) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sss", $username, $hashedPassword, $role);

    if ($stmt->execute()) {
        echo "<script>alert('Signup successful! Please login.'); window.location.href='login.php';</script>";
    } else {
        echo "<script>alert('Error signing up! Please try again.');</script>";
    }

    $stmt->close();
    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="d-flex justify-content-center align-items-center vh-100 bg-light">

<div class="container d-flex justify-content-center align-items-center vh-100">
    <div class="card p-5 shadow-lg" style="width: 800px;">
        <img src="img/teeth.jpg" alt="" class="img-fluid" style="max-width: 200px; height:auto">
        <div class="text-center">
            <h2 class="d-inline align-middle ms-2">CREATE AN ACCOUNT</h2>
        </div>
        <p class="text-center">Fill in your details to register</p>
        <form action="signup.php" method="POST">
            <label>Full Name</label>
            <input type="text" name="name" class="form-control mb-3" placeholder="Your Name" required>
            
            <label>Email</label>
            <input type="email" name="email" class="form-control mb-3" placeholder="Email Address" required>
            
            <label>Password</label>
            <input type="password" name="password" class="form-control mb-3" placeholder="Password" required>
            
            <button type="submit" class="btn btn-primary w-100 mt-3">Sign Up</button>
            <p class="text-center mt-3">Already have an account? <a href="login.php" class="text-decoration-none">Login here</a></p>
        </form>
    </div>
</div>

</body>
</html>
