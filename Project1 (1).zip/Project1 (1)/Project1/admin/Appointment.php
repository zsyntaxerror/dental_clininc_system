<?php
session_start(); // Start the session

$conn = new mysqli("localhost", "root", "", "dental");

// Add this at the top of your Appointment.php file after connecting to the database
$appointmentTypeMap = [
    'consultation' => 'Consultation',
    'restorative' => 'Filling',
    'pediatric' => 'Pediatric Care',
    'routine' => 'Regular Checkup',
    'orthodontics' => 'Orthodontic',
    'endodontics' => 'Root Canal',
    'oral_surgery' => 'Extraction',
    'cleaning' => 'Cleaning'
];


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process status update if needed
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id']) && isset($_POST['status'])) {
    $appointmentId = $_POST['id'];
    $status = $_POST['status'];
    
    // Prepare and execute SQL statement
    $stmt = $conn->prepare("UPDATE appointments SET status = ? WHERE app_id = ?");
    $stmt->bind_param("si", $status, $appointmentId);
    
    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Appointment status updated successfully!";
        // Use header location instead of JSON response when in the same file
        header("Location: Appointment.php");
        exit;
    } else {
        $_SESSION['error_message'] = "Error: " . $stmt->error;
    }
    
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Manager</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/appointment.css">
</head>
<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <nav class="bg-white p-3 shadow-sm vh-100 d-flex flex-column" style="width: 300px;">
            <div class="text-center mb-4">
                <img src="../img/teeth.jpg" alt="" class="w-50">
                <h5 class="fw-bold mt-2">WELCOME!</h5>
                <?php echo isset($_SESSION['user']) ? htmlspecialchars($_SESSION['user']) : 'No email found'; ?>                
            </div>
            <button class="btn btn-primary w-100 mb-3" onclick="location.href='logout.php'">Log out</button>
            <ul class="nav flex-column flex-grow-1">
                <li class="nav-item"><a href="dashboard.php" class="nav-link text-black">Dashboard</a></li>
                <li class="nav-item"><a href="Doctors.php" class="nav-link text-black">Dentist</a></li>
                <li class="nav-item"><a href="schedule.php" class="nav-link text-black">Schedule</a></li>
                <li class="nav-item"><a href="Appointment.php" class="nav-link text-black">Appointment</a></li>
                <li class="nav-item"><a href="patient.php" class="nav-link text-black">Patients</a></li>
            </ul>
        </nav>
     
        <main class="content p-4">
            <div class="d-flex justify-content-between align-items-center">
                <input type="text" class="form-control me-2" placeholder="Search Doctor name or Email">
                <button class="btn btn-primary">Search</button>
            </div>
            <h2 class="mt-4">Appointment Manager</h2>
            <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addAppointmentModal">+ Add New</button>
            <p>All Sessions</p>

            <!-- Display Success Message -->
            <?php
            // Check for a success message in the session
            if (isset($_SESSION['success_message'])) {
                echo '<div class="alert alert-success">' . htmlspecialchars($_SESSION['success_message']) . '</div>';
                // Unset the message after displaying it
                unset($_SESSION['success_message']);
            }

            // Check for an error message in the session
            if (isset($_SESSION['error_message'])) {
                echo '<div class="alert alert-danger">' . htmlspecialchars($_SESSION['error_message']) . '</div>';
                // Unset the message after displaying it
                unset($_SESSION['error_message']);
            }
            ?>

            <!-- Add Appointment Modal -->
            <div class="modal fade" id="addAppointmentModal" tabindex="-1" aria-labelledby="addAppointmentModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="addAppointmentModalLabel">Add New Appointment</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <!-- Replace this section in the modal body -->
<div class="modal-body">
    <form id="addAppointmentForm">
        <div class="mb-3">
            <label for="patientInput" class="form-label">Patient Name</label>
            <input type="text" class="form-control" id="patientInput" name="patientName" required>
        </div>
        <div class="mb-3">
            <label for="doctorSelect" class="form-label">Assign Dentist</label>
            <select class="form-select" id="doctorSelect" name="doctorId" required>
                <option value="">-- Select Dentist --</option>
                <?php
                // Fetch doctors from database
                $doctorSql = "SELECT doc_id, doc_name FROM doctors ORDER BY doc_name";
                $doctorResult = $conn->query($doctorSql);
                
                if ($doctorResult && $doctorResult->num_rows > 0) {
                    while ($doctorRow = $doctorResult->fetch_assoc()) {
                        echo '<option value="' . htmlspecialchars($doctorRow['doc_id']) . '">' . 
                              htmlspecialchars($doctorRow['doc_name']) . 
                              '</option>';
                    }
                }
                ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="appointmentDate" class="form-label">Appointment Date</label>
            <input type="date" class="form-control" id="appointmentDate" name="appointmentDate" required>
        </div>
        <div class="mb-3">
            <label for="appointmentType" class="form-label">Type of Appointment</label>
            <select class="form-select" id="appointmentType" name="appointmentType" required>
                <option value="">-- Select Type --</option>
                <option value="Regular Checkup">Regular Checkup</option>
                <option value="Cleaning">Cleaning</option>
                <option value="Filling">Filling</option>
                <option value="Root Canal">Root Canal</option>
                <option value="Extraction">Extraction</option>
                <option value="Consultation">Consultation</option>
                <option value="Emergency">Emergency</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="status" class="form-label">Status</label>
            <select class="form-select" id="status" name="status" required>
                <option value="Scheduled">Scheduled</option>
                <option value="Completed">Completed</option>
                <option value="Cancelled">Cancelled</option>
                <option value="Pending">Pending</option>
            </select>
             </div>
         <button type="submit" class="btn btn-primary">Add Appointment</button>
                  </form>
            </div>
                       
                    </div>
                </div>
            </div>

            <script>
                document.getElementById('addAppointmentForm').addEventListener('submit', function(event) {
                    event.preventDefault();
                    const formData = new FormData(this);

                    fetch('add_appointment.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // Display success message and refresh page to show updated appointments
                            alert('Appointment added successfully!');
                            location.reload(); // Refresh the page to show the new appointment
                        } else {
                            alert('Failed to add appointment: ' + (data.message || 'Unknown error'));
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('An error occurred while adding the appointment');
                    });
                });
            </script>

            <div class="d-flex mb-3">
                <label class="me-2">Date:</label>
                <input type="date" class="form-control me-2" id="filterDate">
                <label class="me-2">Doctor:</label>
                <select class="form-select" id="filterDoctor">
                    <option value="">All Dentists</option>
                    <?php
                    // Reset the pointer of doctor result set or fetch again
                    if ($doctorResult) {
                        mysqli_data_seek($doctorResult, 0);
                        while ($doctorRow = $doctorResult->fetch_assoc()) {
                            echo '<option value="' . htmlspecialchars($doctorRow['doc_id']) . '">' . 
                                  htmlspecialchars($doctorRow['doc_name']) . 
                                  '</option>';
                        }
                    }
                    ?>
                </select>
                <button class="btn btn-primary ms-2" id="filterButton">Filter</button>
            </div>
            <table class="table mt-4">
                <thead>
                    <tr>
                        <th>Patient Name</th>
                        <th>Appointment Number</th>
                        <th>Dentist</th>
                        <th>Appointment Date</th>
                        <th>Type of Appointment</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Apply filters if they exist
                    $whereClause = "";
                    $params = [];
                    $types = "";
                    
                    if (isset($_GET['date']) && !empty($_GET['date'])) {
                        $whereClause .= " AND a.date = ?";
                        $params[] = $_GET['date'];
                        $types .= "s";
                    }
                    
                    if (isset($_GET['doctor']) && !empty($_GET['doctor'])) {
                        $whereClause .= " AND a.doc_id = ?";
                        $params[] = $_GET['doctor'];
                        $types .= "i";
                    }
                    
                    $sql = "SELECT p.p_name AS patient_name, a.app_id AS appointment_no, d.doc_name AS doctor, 
                    a.date AS appointment_date, a.p_type, a.status, a.sub_service
                    FROM appointments a
                    JOIN patients p ON a.p_id = p.p_id
                    LEFT JOIN doctors d ON a.doc_id = d.doc_id
                    WHERE 1=1" . $whereClause . "
                    ORDER BY a.date DESC";
                    
                    if (!empty($params)) {
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param($types, ...$params);
                        $stmt->execute();
                        $result = $stmt->get_result();
                    } else {
                        $result = $conn->query($sql);
                    }

                    if ($result && $result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo '<tr id="appointment-' . htmlspecialchars($row['appointment_no']) . '">';
                            echo "<td>" . htmlspecialchars($row['patient_name']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['appointment_no']) . "</td>";
                            echo "<td>" . (!empty($row['doctor']) ? htmlspecialchars($row['doctor']) : 'No Dentist Assigned') . "</td>";
                            echo "<td>" . (!empty($row['appointment_date']) ? htmlspecialchars($row['appointment_date']) : 'Not Scheduled') . "</td>";
                            echo "<td>" . (isset($appointmentTypeMap[$row['p_type']]) ? 
                                 htmlspecialchars($appointmentTypeMap[$row['p_type']]) : 
                                  htmlspecialchars($row['p_type'])) . "</td>";
                             echo "<td>" . (strtolower($row['status']) == 'pending' ? 
                                 '<span class="badge bg-warning">Pending</span>' : 
                                    htmlspecialchars($row['status'])) . "</td>";
                                   
                                    echo '<td>
                                    <button class="btn btn-success btn-sm approve-appointment" data-id="' . htmlspecialchars($row['appointment_no']) . '">Approve</button>
                                    <button class="btn btn-primary btn-sm mark-done" data-id="' . htmlspecialchars($row['appointment_no']) . '">Done</button>
                                    <a href="cancel_appointment.php?id=' . htmlspecialchars($row['appointment_no']) . '" 
                                       class="btn btn-danger btn-sm"
                                       onclick="return confirm(\'Are you sure you want to cancel this appointment?\');">
                                       Cancel
                                    </a>
                                 </td>';
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='7' class='text-center'>No Appointments Found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </main>
    </div>

    <script>
        // Filter functionality
        // Filter functionality
document.getElementById('filterButton').addEventListener('click', function() {
    const date = document.getElementById('filterDate').value;
    const doctorId = document.getElementById('filterDoctor').value;
    
    // Build the URL with only non-empty parameters
    let url = 'Appointment.php?';
    let params = [];
    
    if (date) {
        params.push(`date=${encodeURIComponent(date)}`);
    }
    
    if (doctorId) {
        params.push(`doctor=${encodeURIComponent(doctorId)}`);
    }
    
    // Join parameters with & if there are multiple
    url += params.join('&');
    
    // If no parameters were added, just use the base URL
    if (params.length === 0) {
        url = 'Appointment.php';
    }
    
    // Redirect to the new URL
    window.location.href = url;
});

// Add a clear filter button functionality
const addClearFilterButton = () => {
    // Check if there are any filter parameters in the URL
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('date') || urlParams.has('doctor')) {
        // Create clear filters button if it doesn't exist already
        if (!document.getElementById('clearFilters')) {
            const clearBtn = document.createElement('button');
            clearBtn.id = 'clearFilters';
            clearBtn.className = 'btn btn-outline-secondary ms-2';
            clearBtn.textContent = 'Clear Filters';
            clearBtn.addEventListener('click', function() {
                window.location.href = 'Appointment.php';
            });
            
            // Add the button next to the filter button
            document.getElementById('filterButton').parentNode.appendChild(clearBtn);
        }
        
        // Set the filter inputs to match URL parameters
        if (urlParams.has('date')) {
            document.getElementById('filterDate').value = urlParams.get('date');
        }
        
        if (urlParams.has('doctor')) {
            document.getElementById('filterDoctor').value = urlParams.get('doctor');
        }
    }
};

// Call this function when the page loads
document.addEventListener('DOMContentLoaded', addClearFilterButton);
        // Mark appointment as done
        document.querySelectorAll('.mark-done').forEach(button => {
            button.addEventListener('click', function() {
                const appointmentId = this.getAttribute('data-id');
                
                if (confirm('Mark this appointment as completed?')) {
                    // Create a form to submit the data
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.action = 'Appointment.php';
                    
                    const idInput = document.createElement('input');
                    idInput.type = 'hidden';
                    idInput.name = 'id';
                    idInput.value = appointmentId;
                    form.appendChild(idInput);
                    
                    const statusInput = document.createElement('input');
                    statusInput.type = 'hidden';
                    statusInput.name = 'status';
                    statusInput.value = 'Completed';
                    form.appendChild(statusInput);
                    
                    document.body.appendChild(form);
                    form.submit();
                }
            });
        });
        // Add this to your JS section
document.querySelectorAll('.approve-appointment').forEach(button => {
    button.addEventListener('click', function() {
        const appointmentId = this.getAttribute('data-id');
        
        if (confirm('Approve this appointment?')) {
            // Create a form to submit the data
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'Appointment.php';
            
            const idInput = document.createElement('input');
            idInput.type = 'hidden';
            idInput.name = 'id';
            idInput.value = appointmentId;
            form.appendChild(idInput);
            
            const statusInput = document.createElement('input');
            statusInput.type = 'hidden';
            statusInput.name = 'status';
            statusInput.value = 'Scheduled';
            form.appendChild(statusInput);
            
            document.body.appendChild(form);
            form.submit();
        }
    });
});
    </script>
</body>
</html>
<?php
// Close the connection at the end of the file
$conn->close();
?>