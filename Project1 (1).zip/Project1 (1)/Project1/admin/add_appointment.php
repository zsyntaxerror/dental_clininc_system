<?php
session_start();
// Check if the user is authenticated as admin
if($_SESSION['role'] !== 'admin') {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

// Connect to database
$conn = new mysqli("localhost", "root", "", "dental");

// Check connection
if ($conn->connect_error) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit();
}

// Process the form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if patient name was entered
    if (empty($_POST['patientName'])) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Patient name is required']);
        exit();
    }
    
    $patientName = $_POST['patientName'];
    $doctorId = $_POST['doctorId'];
    $appointmentDate = $_POST['appointmentDate'];
    $appointmentType = $_POST['appointmentType'];
    $status = $_POST['status'];
    
    // First check if this patient already exists
    $stmt = $conn->prepare("SELECT p_id FROM patients WHERE p_name = ?");
    $stmt->bind_param("s", $patientName);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        // Patient exists, get their ID
        $patientRow = $result->fetch_assoc();
        $patientId = $patientRow['p_id'];
    } else {
        // Patient doesn't exist, create new patient record
        $stmt = $conn->prepare("INSERT INTO patients (p_name) VALUES (?)");
        $stmt->bind_param("s", $patientName);
        
        if (!$stmt->execute()) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Failed to create new patient: ' . $stmt->error]);
            exit();
        }
        
        $patientId = $conn->insert_id;
    }
    
    // Map the appointment type to the correct value if needed
    $appointmentTypeKey = array_search($appointmentType, [
        'consultation' => 'Consultation',
        'restorative' => 'Filling',
        'pediatric' => 'Pediatric Care',
        'routine' => 'Regular Checkup',
        'orthodontics' => 'Orthodontic',
        'endodontics' => 'Root Canal',
        'oral_surgery' => 'Extraction',
        'cleaning' => 'Cleaning'
    ]);
    
    $typeToInsert = $appointmentTypeKey !== false ? $appointmentTypeKey : $appointmentType;
    
    // Now insert the appointment
    $stmt = $conn->prepare("INSERT INTO appointments (p_id, doc_id, date, p_type, status) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("iisss", $patientId, $doctorId, $appointmentDate, $typeToInsert, $status);
    
    if ($stmt->execute()) {
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'message' => 'Appointment added successfully']);
    } else {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Failed to add appointment: ' . $stmt->error]);
    }
    
    $stmt->close();
} else {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

$conn->close();
?>