<?php
session_start();
include 'db.php'; // Database connection file

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'You must be logged in to perform this action']);
    exit;
}

// Check if appointment_id is provided
if (!isset($_POST['appointment_id']) || empty($_POST['appointment_id'])) {
    echo json_encode(['success' => false, 'message' => 'Appointment ID is required']);
    exit;
}

$appointment_id = mysqli_real_escape_string($conn, $_POST['appointment_id']);

// Delete the appointment
$query = "DELETE FROM appointments WHERE app_id = '$appointment_id'";
$result = mysqli_query($conn, $query);

if ($result) {
    echo json_encode(['success' => true, 'message' => 'Appointment removed successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to remove appointment: ' . mysqli_error($conn)]);
}
?>