<?php
include('c.php'); // Ensure database connection

$name = "Admin";
$email = "admin@gmail.com";
$password = "admin123";
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Check if the email already exists
$sql_check = "SELECT id FROM users WHERE email = ?";
$stmt_check = $conn->prepare($sql_check);
$stmt_check->bind_param("s", $email);
$stmt_check->execute();
$stmt_check->store_result();

if ($stmt_check->num_rows > 0) {
    // Email exists, update the existing user
    $sql_update = "UPDATE users SET name = ?, password = ? WHERE email = ?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param("sss", $name, $hashed_password, $email);

    if ($stmt_update->execute()) {
        echo "User updated successfully!";
    } else {
        echo "Error: " . $stmt_update->error;
    }

    $stmt_update->close();
} else {
    // Email does not exist, insert a new user
    $sql_insert = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
    $stmt_insert = $conn->prepare($sql_insert);
    $stmt_insert->bind_param("sss", $name, $email, $hashed_password);

    if ($stmt_insert->execute()) {
        echo "User added successfully!";
    } else {
        echo "Error: " . $stmt_insert->error;
    }

    $stmt_insert->close();
}

$stmt_check->close();
$conn->close();
?>


