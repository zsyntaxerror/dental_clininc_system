<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="d-flex justify-content-center align-items-center vh-100 bg-light">

<div class="container d-flex justify-content-center align-items-center vh-100">
    <div class="card p-5 shadow-lg" style="width: 800px;">
    <img src="img/teeth.jpg" alt="" class="img-fluid" style="max-width: 200px;   vertical-align: middle; height:auto">
        <div class="text-center">
            <h2 class="d-inline align-middle ms-2">WELCOME BACK!</h2>
        </div>
        <p class="text-center">Login with your details to continue</p>
        <form action="authenticate.php" method="POST">
    <label>Email</label>
    <input type="email" name="email" class="form-control mb-3" placeholder="Email Address" required>

    <label>Password</label>
    <input type="password" name="password" class="form-control mb-3" placeholder="Password" required>

    <div class="text-center">
        <a href="#" class="text-decoration-none">Forget Password?</a>
    </div>

    <button type="submit" class="btn btn-primary w-100 mt-3">Login</button>
    <button type="button" class="btn btn-outline-primary w-100 mt-2">Sign up</button>
</form>

        </form>
    </div>
</div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
