<?php

// At the top of dashboard.php, add this code
session_start();
if(!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}


// Database connection
$conn = new mysqli("localhost", "root", "", "dental");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Appointment type mapping
$appointmentTypeMap = [
    'consultation' => 'Consultation',
    'restorative' => 'Filling',
    'pediatric' => 'Pediatric Care',
    'routine' => 'Regular Checkup',
    'orthodontics' => 'Orthodontic',
    'endodontics' => 'Root Canal',
    'oral_surgery' => 'Extraction',
    'cleaning' => 'Cleaning'
];

// Get counts for status boxes
$doctorCount = $conn->query("SELECT COUNT(*) as count FROM doctors")->fetch_assoc()['count'];
$patientCount = $conn->query("SELECT COUNT(*) as count FROM patients")->fetch_assoc()['count'];
$newBookingCount = $conn->query("SELECT COUNT(*) as count FROM appointments WHERE status = 'Pending'")->fetch_assoc()['count'];
$todaySessionCount = $conn->query("SELECT COUNT(*) as count FROM appointments WHERE DATE(date) = CURDATE()")->fetch_assoc()['count'];

// Get latest appointments for dashboard table
$appointmentSql = "SELECT a.app_id, p.p_name, d.doc_name, a.p_type, a.sub_service
                   FROM appointments a
                   JOIN patients p ON a.p_id = p.p_id
                   LEFT JOIN doctors d ON a.doc_id = d.doc_id
                   ORDER BY a.date DESC LIMIT 5";
$appointmentResult = $conn->query($appointmentSql);

// Get upcoming sessions
$sessionSql = "SELECT a.p_type as title, d.doc_name, a.date
               FROM appointments a
               LEFT JOIN doctors d ON a.doc_id = d.doc_id
               WHERE a.date >= CURDATE()
               ORDER BY a.date ASC LIMIT 5";
$sessionResult = $conn->query($sessionSql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/admindashboard.css">
</head>
<body>
<div class="d-flex">
<nav class="bg-white p-3 shadow-sm vh-100" style="width: 300px; position: fixed;">
    <div class="text-center mb-4">
        <img src="../img/teeth.jpg" alt="" class="w-50">
        <h5 class="fw-bold mt-2">WELCOME!</h5>
        <?php echo isset($_SESSION['user']) ? htmlspecialchars($_SESSION['user']) : 'No email found'; ?>       
    </div>
    <button class="btn btn-primary w-100 mb-3" onclick="location.href='logout.php'">Log out</button>
    <ul class="nav flex-column">
        <li class="nav-item"><a href="dashboard.php" class="nav-link text-black">Dashboard</a></li>
        <li class="nav-item"><a href="Doctors.php" class="nav-link text-black">Dentist</a></li>
        <li class="nav-item"><a href="schedule.php" class="nav-link text-black">Schedule</a></li>
        <li class="nav-item"><a href="Appointment.php" class="nav-link text-black">Appointment</a></li>
        <li class="nav-item"><a href="patient.php" class="nav-link text-black">Patients</a></li>
    </ul>
</nav>
<div class="container-fluid p-4" style="margin-left: 300px;">
    
    <h4 class="fw-bold">Status</h4>
    <div class="row my-3">
        <div class="col-md-3">
            <div class="border rounded p-3 shadow-sm text-center">Doctors <span class="fw-bold text-primary"><?php echo $doctorCount; ?></span></div>
        </div>
        <div class="col-md-3">
            <div class="border rounded p-3 shadow-sm text-center">Patients <span class="fw-bold text-primary"><?php echo $patientCount; ?></span></div>
        </div>
        <div class="col-md-3">
            <div class="border rounded p-3 shadow-sm text-center">New Booking <span class="fw-bold text-primary"><?php echo $newBookingCount; ?></span></div>
        </div>
        <div class="col-md-3">
            <div class="border rounded p-3 shadow-sm text-center">Today Sessions <span class="fw-bold text-primary"><?php echo $todaySessionCount; ?></span></div>
        </div>
    </div>
    <div class="card p-3 shadow-sm border-0">
        <h5>Appointments</h5>
        <table class="table table-bordered mt-2">
            <thead>
                <tr>
                    <th>Appointment number</th>
                    <th>Patient name</th>
                    <th>Doctor</th>
                    <th>Session</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($appointmentResult && $appointmentResult->num_rows > 0) {
                    while ($row = $appointmentResult->fetch_assoc()) {
                        // Get the formatted appointment type
                        $appointmentType = isset($appointmentTypeMap[$row['p_type']]) ? 
                            $appointmentTypeMap[$row['p_type']] : $row['p_type'];
                            
                        // Use sub_service if available, otherwise use the appointment type
                        $sessionDisplay = !empty($row['sub_service']) ? $row['sub_service'] : $appointmentType;
                        
                        echo '<tr>';
                        echo '<td>' . htmlspecialchars($row['app_id']) . '</td>';
                        echo '<td>' . htmlspecialchars($row['p_name']) . '</td>';
                        echo '<td>' . (!empty($row['doc_name']) ? htmlspecialchars($row['doc_name']) : 'Not Assigned') . '</td>';
                        echo '<td>' . htmlspecialchars($sessionDisplay) . '</td>';
                        echo '</tr>';
                    }
                } else {
                    echo '<tr><td colspan="4" class="text-center">No appointments found</td></tr>';
                }
                ?>
            </tbody>
        </table>
        <button class="btn btn-primary w-100" onclick="location.href='Appointment.php'">Show all Appointments</button>
    </div>

    <div class="card p-3 shadow-sm border-0 mt-4">
        <h5>Sessions</h5>
        <table class="table table-bordered mt-2">
            <thead>
                <tr>
                    <th>Session Title</th>
                    <th>Doctor</th>
                    <th>Scheduled Date & Time</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($sessionResult && $sessionResult->num_rows > 0) {
                    while ($row = $sessionResult->fetch_assoc()) {
                        // Format the title
                        $sessionTitle = isset($appointmentTypeMap[$row['title']]) ? 
                            $appointmentTypeMap[$row['title']] : $row['title'];
                            
                        // Format the date and time
                        $dateTime = new DateTime($row['date']);
                        $formattedDate = $dateTime->format('F j, Y - g:i A');
                        
                        echo '<tr>';
                        echo '<td>' . htmlspecialchars($sessionTitle) . '</td>';
                        echo '<td>' . (!empty($row['doc_name']) ? htmlspecialchars($row['doc_name']) : 'Not Assigned') . '</td>';
                        echo '<td>' . htmlspecialchars($formattedDate) . '</td>';
                        echo '</tr>';
                    }
                } else {
                    echo '<tr><td colspan="3" class="text-center">No upcoming sessions found</td></tr>';
                }
                ?>
            </tbody>
        </table>
        <button class="btn btn-primary w-100" onclick="location.href='schedule.php'">Show all Sessions</button>
    </div>
</div>
</body>
</html>
<?php
// Close the database connection
$conn->close();
?>