<?php
session_start();

// Database connection
$conn = new mysqli("localhost", "root", "", "dental");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if ID is provided
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $appointmentId = $_GET['id'];
    
    // Prepare and execute SQL statement to update status to Cancelled
    $stmt = $conn->prepare("UPDATE appointments SET status = 'Cancelled' WHERE app_id = ?");
    $stmt->bind_param("i", $appointmentId);
    
    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Appointment successfully cancelled";
    } else {
        $_SESSION['error_message'] = "Error cancelling appointment: " . $stmt->error;
    }
    
    $stmt->close();
} else {
    $_SESSION['error_message'] = "No appointment ID provided";
}

// Close connection
$conn->close();

// Redirect back to the appointment page
header("Location: Appointment.php");
exit;
?>