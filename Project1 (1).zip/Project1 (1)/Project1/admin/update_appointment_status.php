<?php
session_start();

// Database connection
$conn = new mysqli("localhost", "root", "", "dental");

// Check connection
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Connection failed: ' . $conn->connect_error]));
}

// Check if necessary data is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id']) && isset($_POST['status'])) {
    $appointmentId = $_POST['id'];
    $status = $_POST['status'];
    
    // Prepare and execute SQL statement
    $stmt = $conn->prepare("UPDATE appointments SET status = ? WHERE app_id = ?");
    $stmt->bind_param("si", $status, $appointmentId);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
        $_SESSION['success_message'] = "Appointment status updated successfully!";
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $stmt->error]);
    }
    
    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Missing required parameters']);
}

$conn->close();
?>