<?php
ob_start(); // Prevent output before header()
session_start();

$_SESSION["user"] = ""; 
$_SESSION["role"] = "";
$_SESSION["p_id"] = ""; // Initialize for patient, change to p_id 

include("connection.php");

$error = '<label for="promter" class="form-label"></label>';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['useremail'];
    $password = $_POST['userpassword'];

    // Patient login check
    $checker = $database->query("SELECT * FROM patients WHERE p_email='$email'");

    if ($checker && $checker->num_rows == 1) {
        $patient_data = $checker->fetch_assoc();

        if (password_verify($password, $patient_data['p_password'])) {
            $_SESSION['p_id'] = $patient_data['p_id']; // Update this to match your database
            $_SESSION['user'] = $email;
            $_SESSION['role'] = 'patient';

            // Redirect to client dashboard
            header('Location: client/dashboard.php');
            exit();
        } else {
            $error = '<label for="promter" class="form-label" style="color:red;text-align:center;">Invalid email or password</label>';
        }
    } else {
        // Admin login check
        $admin_check = $database->query("SELECT * FROM admin WHERE aemail='$email'");
        if ($admin_check && $admin_check->num_rows == 1) {
            $admin_data = $admin_check->fetch_assoc();

            // Try password_verify first (for hashed passwords)
            if (password_verify($password, $admin_data['apassword'])) {
                $_SESSION['user_id'] = $admin_data['id']; 
                $_SESSION['user'] = $email;
                $_SESSION['role'] = 'admin';

                header('Location: admin/dashboard.php');
                exit();
            } else if ($password === $admin_data['apassword']) {
                $_SESSION['user'] = $email;
                $_SESSION['role'] = 'admin';

                header('Location: admin/dashboard.php');
                exit();
            } else {
                $error = '<label for="promter" class="form-label" style="color:red;text-align:center;">Invalid email or password</label>';
            }
        } else {
            $error = '<label for="promter" class="form-label" style="color:red;text-align:center;">Invalid email or password</label>';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</head>
<body class="d-flex justify-content-center align-items-center vh-100 bg-light">

<div class="container d-flex justify-content-center align-items-center vh-100">
    <div class="card p-5 shadow-lg" style="width: 800px;">
        <img src="img/teeth.jpg" alt="" class="img-fluid mx-auto" style="max-width: 150px; height: auto">
        <div class="text-center">
            <h2 class="text-info-black">WELCOME BACK!</h2>
        </div>
        <p class="text-center">Login with your details to continue</p>
        
        <form action="" method="POST">
            <div class="mb-3">
                <label for="useremail">Email</label>
                <input type="email" name="useremail" id="useremail" class="form-control" placeholder="Email Address" required>
            </div>

            <div class="mb-3">
                <label for="userpassword">Password</label>
                <input type="password" name="userpassword" id="userpassword" class="form-control" placeholder="Password" required>
            </div>
               
            <?php echo $error ?>
                
            <input type="submit" value="Login" class="btn btn-primary w-100 mt-3">
            <a href="signup.php" class="btn btn-outline-primary w-100 mt-2">Sign Up</a>
        </form>
    </div>
</div>
</body>
</html>