<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html><div class="sidebar">
    <div class="logo">
        <img src="path_to_logo.png" alt="Logo">
    </div>
    <button class="logout-btn">Log out</button>
    <ul>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="dentist.php">Dentist</a></li>
        <li><a href="schedule.php">Schedule</a></li>
        <li><a href="appointment.php">Appointment</a></li>
        <li><a href="patients.php">Patients</a></li>
    </ul>
</div>

---

### 2. **I-include ang sidebar sa bawat page**
Sa bawat file ng page mo (`dashboard.php`, `schedule.php`, `appointment.php`, etc.), idagdag ang code na ito sa part kung saan mo gustong lumabas ang sidebar:

```php
<?php include 'sidebar.php'; ?>
