<?php 
session_start(); 
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'patient') {
    header("Location: login.php");
    exit();
}

// Get appointment ID from URL
$appointment_id = $_GET['id'] ?? 0;

// Connect to database to get current appointment details
$conn = new mysqli('localhost', 'root', '', 'dental');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get current appointment details
$p_id = $_SESSION['p_id'];
$stmt = $conn->prepare("SELECT a.*, d.doc_name
                       FROM appointments a
                       JOIN doctors d ON a.doc_id = d.doc_id
                       WHERE a.app_id = ? AND a.p_id = ?");
$stmt->bind_param("ii", $appointment_id, $p_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "Invalid appointment.";
    header("Location: appointment_summary.php");
    exit();
}

$appointment = $result->fetch_assoc();
$stmt->close();
$conn->close();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $appointment_id = $_POST['appointment_id'] ?? '';
    $new_date = $_POST['new_date'] ?? '';
    $new_time = $_POST['new_time'] ?? '';
    
    // Validate inputs
    if (empty($appointment_id) || empty($new_date) || empty($new_time)) {
        $_SESSION['error'] = "All fields are required.";
        header("Location: appointment_summary.php");
        exit();
    }
    
    // Connect to database
    $conn = new mysqli('localhost', 'root', '', 'dental');
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    // Check if appointment belongs to current user
    $p_id = $_SESSION['p_id'];
    $check_stmt = $conn->prepare("SELECT app_id FROM appointments WHERE app_id = ? AND p_id = ?");
    $check_stmt->bind_param("ii", $appointment_id, $p_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows === 0) {
        $_SESSION['error'] = "Invalid appointment.";
        header("Location: appointment_summary.php");
        exit();
    }
    $check_stmt->close();
    
    // Update appointment
    $update_stmt = $conn->prepare("UPDATE appointments SET date = ?, time = ? WHERE app_id = ?");
    $update_stmt->bind_param("ssi", $new_date, $new_time, $appointment_id);
    
    if ($update_stmt->execute()) {
        $_SESSION['message'] = "Appointment rescheduled successfully.";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Failed to reschedule appointment: " . $conn->error;
        $_SESSION['message_type'] = "danger";
    }
    
    $update_stmt->close();
    $conn->close();
    
    header("Location: appointment_summary.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reschedule Appointment</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        
        .card {
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }
        
        .btn-primary {
            background-color: #0d6efd;
            border: none;
        }
        
        .btn-outline-secondary {
            color: #6c757d;
            border-color: #6c757d;
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">Reschedule Appointment</h4>
                    </div>
                    <div class="card-body">
                        <div class="mb-4">
                            <h5>Current Appointment Details</h5>
                            <p><strong>Doctor:</strong> <?php echo htmlspecialchars($appointment['doc_name']); ?></p>
                            <p><strong>Service:</strong> <?php echo htmlspecialchars($appointment['p_type']); ?> - <?php echo htmlspecialchars($appointment['sub_service'] ?? ''); ?></p>
                            <p><strong>Current Date:</strong> <?php echo htmlspecialchars($appointment['date']); ?></p>
                            <p><strong>Current Time:</strong> <?php echo htmlspecialchars($appointment['time']); ?></p>
                        </div>
                        
                        <form action="reschedule.php" method="post">
                            <input type="hidden" name="appointment_id" value="<?php echo $appointment_id; ?>">
                            
                            <div class="mb-3">
                                <label for="new_date" class="form-label">New Date</label>
                                <input type="date" class="form-control" id="new_date" name="new_date" required min="<?php echo date('Y-m-d'); ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label for="new_time" class="form-label">New Time</label>
                                <select class="form-select" id="new_time" name="new_time" required>
                                    <option value="">Select a time slot</option>
                                    <option value="09:00:00">09:00 AM</option>
                                    <option value="10:00:00">10:00 AM</option>
                                    <option value="11:00:00">11:00 AM</option>
                                    <option value="13:00:00">01:00 PM</option>
                                    <option value="14:00:00">02:00 PM</option>
                                    <option value="15:00:00">03:00 PM</option>
                                    <option value="16:00:00">04:00 PM</option>
                                </select>
                            </div>
                            
                            <div class="d-flex justify-content-between">
                                <a href="appointment_summary.php" class="btn btn-outline-secondary">
                                    <i class="bi bi-arrow-left"></i> Back to Appointments
                                </a>
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-calendar-check"></i> Reschedule Appointment
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>