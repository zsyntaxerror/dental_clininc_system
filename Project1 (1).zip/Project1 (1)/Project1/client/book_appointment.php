<?php
session_start();
include '../client/connection.php';

function book_appointment($conn) {
    // Existing validation code...
    
    // In book_appointment.php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && 
isset($_POST['appointment_type'], $_POST['sub_service'], $_POST['appointment_date'], $_POST['appointment_time'], $_POST['doctor_id'])) {

$appointment_type = $_POST['appointment_type'];
$sub_service = $_POST['sub_service'];
$appointment_date = $_POST['appointment_date'];
$appointment_time = $_POST['appointment_time'];
$patient_id = $_SESSION['p_id'];
$doc_id = $_POST['doctor_id']; // Use the selected doctor ID directly

// Remove the random doctor selection query since we're using the client's selection

// Use a status field to indicate pending admin approval
$status = "pending"; 
$sched_id = 1; // Default value - replace with actual value based on your logic

$stmt = $conn->prepare("INSERT INTO appointments (p_id, doc_id, sched_id, p_type, sub_service, date, time, status)    
VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending')");

$stmt->bind_param("iiissss", $patient_id, $doc_id, $sched_id, $appointment_type, $sub_service, $appointment_date, $appointment_time);

// Execute and check for success
if ($stmt->execute()) {
    $_SESSION['success_message'] = 'Your appointment request has been sent successfully. An administrator will review and confirm your appointment.';
    header("Location: ../client/confirmation.php");
    exit();
} else {
    echo "Error: " . htmlspecialchars($stmt->error);
}
$stmt->close();
}
}

// Call the booking function
book_appointment($conn); // Pass the connection object to the function
$conn->close(); // Close the connection
?>