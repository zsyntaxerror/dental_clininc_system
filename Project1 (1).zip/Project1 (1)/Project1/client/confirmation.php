<?php
session_start();
include 'connection.php'; // Ensure the path to your connection file is correct

// Debug session contents (you can remove this after debugging)
error_log("Session contents: " . print_r($_SESSION, true));

// Check if there is an active session - modify this to check for p_id instead of user_email
if (!isset($_SESSION['p_id'])) {
    header("Location: index.php"); // Redirect to the homepage if no session is found
    exit();
}

$patient_id = $_SESSION['p_id'];
$row = null; // Initialize $row to avoid undefined variable errors

// Use prepared statement to prevent SQL Injection - modify to use p_id instead of email
try {
    $stmt = $conn->prepare("SELECT p.p_name AS patient_name, a.app_id AS appointment_no, d.doc_name AS dentist,
                              a.date AS appointment_date, a.time AS appointment_time, a.p_type AS service
                       FROM appointments a
                       JOIN patients p ON a.p_id = p.p_id
                       JOIN doctors d ON a.doc_id = d.doc_id
                       WHERE a.p_id = ?
                       ORDER BY a.app_id DESC LIMIT 1");
    
    if ($stmt === false) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    
    $stmt->bind_param("i", $patient_id); // Changed from "s" to "i" for integer patient ID
    
    if (!$stmt->execute()) {
        throw new Exception("Execute failed: " . $stmt->error);
    }
    
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc(); // Fetch appointment details
    } else {
        error_log("No appointment found for patient ID: $patient_id");
    }
    
    $stmt->close(); // Close the statement
} catch (Exception $e) {
    // Log the error and display a user-friendly message
    error_log("Database error: " . $e->getMessage());
    echo "<div style='color:red'>An error occurred while retrieving your appointment information. Please try again later.</div>";
}

$conn->close(); // Close the connection
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Confirmation</title>
    <link rel="stylesheet" href="styles.css"> <!-- Ensure this file exists -->
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 20px;
            background-color: #f4f4f4; /* Light gray background for better contrast */
            border-radius: 8px;
        }
        h2 {
            color: #333; /* Dark text for headers */
        }
        p {
            color: #555; /* Slightly lighter text for paragraphs */
        }
        a {
            color: #007bff; /* Bootstrap primary color */
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline; /* Underline on hover */
        }
        .success-message {
            background-color: #d4edda;
            color: #155724;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="success-message">
            <?php 
            echo htmlspecialchars($_SESSION['success_message']); 
            unset($_SESSION['success_message']); // Clear the message after displaying it
            ?>
        </div>
    <?php endif; ?>

    <h2>Welcome, <?php echo htmlspecialchars($row['patient_name'] ?? 'Guest'); ?>!</h2>
    
    <?php if ($row): ?>
        <p>Your appointment for <strong><?php echo htmlspecialchars($row['service']); ?></strong> with <strong><?php echo htmlspecialchars($row['dentist']); ?></strong> on <strong><?php echo htmlspecialchars($row['appointment_date']); ?></strong> at <strong><?php echo htmlspecialchars($row['appointment_time']); ?></strong> has been successfully booked.</p>
        <p>Appointment Number: <strong><?php echo htmlspecialchars($row['appointment_no']); ?></strong></p>
    <?php else: ?>
        <p>Sorry, no appointment found. Please return to the <a href="../client/schedule.php">dashboard</a> to schedule a new appointment.</p>
    <?php endif; ?>
    
    <a href="../client/dashboard.php">Go to Dashboard</a>
</body>
</html>