<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root"; // Default XAMPP username
$password = ""; // Default XAMPP password
$dbname = "dental"; // Replace with your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$patient_email = $_SESSION['user'];
$patient_query = $conn->prepare("SELECT p_name FROM patients WHERE p_email = ?");
$patient_query->bind_param("s", $patient_email);
$patient_query->execute();
$patient_result = $patient_query->get_result();

$patient_name = "User";
if ($patient_result->num_rows > 0) {
    $patient_data = $patient_result->fetch_assoc();
    $patient_name = $patient_data['p_name'];
}
$patient_query->close();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'patient') {
    header("Location: login.php");
    exit();
}

// Rest of your code remains the same...

// Placeholder data - in a real app, this would come from your database
// Get doctor count
// First, get the patient's ID from the patients table
$patient_id_query = $conn->prepare("SELECT p_id FROM patients WHERE p_email = ?");
$patient_id_query->bind_param("s", $patient_email);
$patient_id_query->execute();
$patient_id_result = $patient_id_query->get_result();
$patient_id = 0; // Default value

if ($patient_id_result->num_rows > 0) {
    $patient_id_data = $patient_id_result->fetch_assoc();
    $patient_id = $patient_id_data['p_id'];
}
$patient_id_query->close();

// Get doctor count
$doctor_query = "SELECT COUNT(*) as doctor_count FROM doctors";
$doctor_result = $conn->query($doctor_query);
$doctorCount = 0; // Default value
if ($doctor_result && $doctor_result->num_rows > 0) {
    $doctor_data = $doctor_result->fetch_assoc();
    $doctorCount = $doctor_data['doctor_count'];
}

// Get patient's scheduled sessions (upcoming appointments)
$scheduled_query = $conn->prepare("SELECT COUNT(*) as session_count FROM appointments 
                                  WHERE p_id = ? AND date >= CURDATE()");
$scheduled_query->bind_param("i", $patient_id);  // Note: "i" for integer parameter
$scheduled_query->execute();
$scheduled_result = $scheduled_query->get_result();
$patientSessionCount = 0;
if ($scheduled_result->num_rows > 0) {
    $scheduled_data = $scheduled_result->fetch_assoc();
    $patientSessionCount = $scheduled_data['session_count'];
}
$scheduled_query->close();

// Get patient's total bookings
$bookings_query = $conn->prepare("SELECT COUNT(*) as booking_count FROM appointments 
                                 WHERE p_id = ?");
$bookings_query->bind_param("i", $patient_id);  // "i" for integer
$bookings_query->execute();
$bookings_result = $bookings_query->get_result();
$newBookingCount = 0;
if ($bookings_result->num_rows > 0) {
    $bookings_data = $bookings_result->fetch_assoc();
    $newBookingCount = $bookings_data['booking_count'];
}
$bookings_query->close();

// Get today's sessions
$today_query = $conn->prepare("SELECT COUNT(*) as today_count FROM appointments 
                              WHERE p_id = ? AND date = CURDATE()");
$today_query->bind_param("i", $patient_id);  // "i" for integer
$today_query->execute();
$today_result = $today_query->get_result();
$todaySessionsCount = 0;
if ($today_result->num_rows > 0) {
    $today_data = $today_result->fetch_assoc();
    $todaySessionsCount = $today_data['today_count'];
}
$today_query->close();

// Get patient's bookings (total appointments)
// Get patient's bookings (total appointments)
$bookings_query = $conn->prepare("SELECT COUNT(*) as booking_count FROM appointments 
                                 WHERE p_id = ?");
$bookings_query->bind_param("i", $patient_id); // "i" for integer, not "s"
$bookings_query->execute();
$bookings_result = $bookings_query->get_result();
$newBookingCount = 0;
if ($bookings_result->num_rows > 0) {
    $bookings_data = $bookings_result->fetch_assoc();
    $newBookingCount = $bookings_data['booking_count'];
}
$bookings_query->close();


// Get today's sessions
$today_query = $conn->prepare("SELECT COUNT(*) as today_count FROM appointments 
                              WHERE p_id = ? AND date = CURDATE()");
$today_query->bind_param("i", $patient_id); // "i" for integer
$today_query->execute();
$today_result = $today_query->get_result();
$todaySessionsCount = 0;
if ($today_result->num_rows > 0) {
    $today_data = $today_result->fetch_assoc();
    $todaySessionsCount = $today_data['today_count'];
}
$today_query->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        
        .sidebar {
            background-color: white;
            height: 100vh;
            position: sticky;
            top: 0;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        
        .sidebar .nav-link {
            color: #333;
            padding: 10px 15px;
            border-radius: 5px;
            margin-bottom: 5px;
            display: flex;
            align-items: center;
        }
        
        .sidebar .nav-link.active {
            background-color: #e9f0ff;
            color: #0d6efd;
            font-weight: 500;
        }
        
        .sidebar .nav-link:hover {
            background-color: #f0f0f0;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            padding: 20px;
        }
        
        .profile-section {
            text-align: center;
            padding: 20px 10px;
            border-bottom: 1px solid #eee;
            margin-bottom: 20px;
        }
        
        .profile-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background-color: #e9ecef;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
        }
        
        .profile-avatar i {
            font-size: 40px;
            color: #6c757d;
        }
        
        .log-out-btn {
            background-color: #e9f0ff;
            color: #0d6efd;
            border: none;
            border-radius: 5px;
            padding: 8px 15px;
            width: 100%;
            margin-bottom: 20px;
            font-weight: 500;
        }
        
        .log-out-btn:hover {
            background-color: #d8e5ff;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .date-display {
            text-align: right;
        }
        
        .search-bar {
            margin-bottom: 20px;
        }
        
        .search-container {
            position: relative;
            display: flex;
        }
        
        .search-input {
            border-radius: 5px;
            border: 1px solid #ced4da;
            padding: 10px 15px;
            flex-grow: 1;
        }
        
        .search-btn {
            margin-left: 10px;
        }
        
        .welcome-banner {
            background-color: #d1e7dd;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            position: relative;
            overflow: hidden;
        }
        
        .welcome-banner h1 {
            font-size: 28px;
            font-weight: 600;
            margin-bottom: 15px;
        }
        
        .welcome-banner p {
            font-size: 16px;
            max-width: 600px;
            margin-bottom: 15px;
        }
        
        .stats-card {
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
            height: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            transition: transform 0.3s ease;
        }
        
        .stats-card:hover {
            transform: translateY(-5px);
        }
        
        .stats-card .number {
            font-size: 32px;
            font-weight: 600;
            color: #0d6efd;
            margin: 10px 0;
        }
        
        .stats-card .label {
            color: #6c757d;
        }
        
        .stats-card .icon {
            font-size: 24px;
            width: 50px;
            height: 50px;
            background-color: #e9f0ff;
            color: #0d6efd;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 15px;
        }
        
        .appointment-table {
            background-color: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
            margin-top: 30px;
        }
        
        .appointment-table .table {
            margin-bottom: 0;
        }
        
        .appointment-table th {
            background-color: #f8f9fa;
            font-weight: 500;
            padding: 15px;
        }
        
        .appointment-table td {
            padding: 15px;
            vertical-align: middle;
        }
        
        .appointment-type-cards {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-top: 30px;
            margin-bottom: 30px;
        }
        
        .appointment-type-card {
            background-color: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
            transition: transform 0.3s ease;
        }
        
        .appointment-type-card:hover {
            transform: translateY(-5px);
        }
        
        .appointment-type-card img {
            width: 100%;
            height: 150px;
            object-fit: cover;
        }
        
        .appointment-type-content {
            padding: 15px;
            text-align: center;
        }
        
        .appointment-type-content h5 {
            margin-bottom: 10px;
            font-weight: 500;
        }
        
        .appointment-type-content p {
            color: #6c757d;
            margin-bottom: 0;
        }
        
        .schedule-btn {
            background-color: #0d6efd;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            font-weight: 500;
            margin-top: 30px;
            width: auto;
            display: block;
            margin-left: auto;
            margin-right: auto;
        }
        
        .schedule-btn:hover {
            background-color: #0b5ed7;
        }
        
        @media (max-width: 992px) {
            .appointment-type-cards {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        
        @media (max-width: 576px) {
            .appointment-type-cards {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 p-0 sidebar">
            <div class="profile-section">
        <div class="profile-avatar">
        <i class="bi bi-person"></i>
        </div>
        <h5 class="mb-1"><?php echo htmlspecialchars($patient_name); ?></h5>
        <p class="text-muted small mb-3"><?php echo htmlspecialchars($_SESSION['user']); ?></p>
        <button class="log-out-btn" onclick="location.href='../login.php'">Log out</button>
        </div>
           
              
                <div class="px-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a href="../client/dashboard.php" class="nav-link active">
                                <i class="bi bi-house"></i> Home
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="../client/Doctors.php" class="nav-link">
                                <i class="bi bi-people"></i> All Dentist
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="../client/schedule.php" class="nav-link">
                                <i class="bi bi-calendar-check"></i> Scheduled Sessions
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="../client/appointment_summary.php" class="nav-link">
                                <i class="bi bi-bookmark"></i> My Bookings
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="../client/settings.php" class="nav-link">
                                <i class="bi bi-gear"></i> Settings
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content">
                <div class="header">
                    <h2>Home</h2>
                    <div class="date-display">
                        <p class="mb-0 text-muted">Today's Date</p>
                        <h5><?php echo date('Y-m-d'); ?></h5>
                    </div>
                </div>

                <!-- Welcome Banner -->
                <div class="welcome-banner">
                <h1>Welcome!</h1>
                    <h3><?php echo htmlspecialchars($patient_name); ?></h3>
                     <p>
                          Dental clinic
                    </p>
                    
                    <div class="mt-4">
                        <h5>Channel a Doctor Here</h5>
                        <div class="search-container">
                            <input type="text" class="form-control search-input" placeholder="Search Doctor and We will Find The Session Available">
                            <button class="btn btn-primary search-btn">Search</button>
                        </div>
                    </div>
                </div>

                <!-- Status Cards -->
                 <!-- Status Cards -->
<h4>Status</h4>
<div class="row g-4 mt-2">
    <div class="col-md-3">
        <div class="stats-card">
            <div class="icon">
                <i class="bi bi-people"></i>
            </div>
            <a href="doctors.php" class="text-decoration-none text-dark">
                <div class="number"><?php echo $doctorCount; ?></div>
                <div class="label">All Doctors</div>
            </a>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stats-card">
            <div class="icon">
                <i class="bi bi-person"></i>
            </div>
            <a href="schedule.php" class="text-decoration-none text-dark">
                <div class="number"><?php echo $patientSessionCount; ?></div>
                <div class="label">Schedule Appointment</div>
            </a>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stats-card">
            <div class="icon">
                <i class="bi bi-bookmark"></i>
            </div>
            <a href="appointment_summary.php" class="text-decoration-none text-dark">
                <div class="number"><?php echo $newBookingCount; ?></div>
                <div class="label">MyBooking</div>
            </a>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stats-card">
            <div class="icon">
                <i class="bi bi-calendar-check"></i>
            </div>
            <a href="schedule.php" class="text-decoration-none text-dark">
                <div class="number"><?php echo $todaySessionsCount; ?></div>
                <div class="label">Today Sessions</div>
            </a>
        </div>
    </div>
</div>
              

                <!-- Types of Appointments -->
                <h4 class="mt-5">Types of Appointments</h4>
                <div class="appointment-type-cards">
                    <div class="appointment-type-card">
                        <img src="../img/1.jpeg" alt="Consultation & Diagnosis" onerror="this.src='https://via.placeholder.com/300x200?text=Consultation'">
                        <div class="appointment-type-content">
                            <h5>Consultation & Diagnosis</h5>
                            <p>Price: ₱100.00</p>
                        </div>
                    </div>
                    <div class="appointment-type-card">
                        <img src="../img/2.jpeg" alt="Restorative Treatment" onerror="this.src='https://via.placeholder.com/300x200?text=Restorative'">
                        <div class="appointment-type-content">
                            <h5>Restorative Treatment</h5>
                            <p>Price: ₱500.00</p>
                        </div>
                    </div>
                    <div class="appointment-type-card">
                        <img src="../img/pediatric.jpg" alt="Pediatric Dentistry" onerror="this.src='https://via.placeholder.com/300x200?text=Pediatric'">
                        <div class="appointment-type-content">
                            <h5>Pediatric Dentistry</h5>
                            <p>Price: ₱100.00</p>
                        </div>
                    </div>
                    <div class="appointment-type-card">
                        <img src="../img/3.jpg" alt="Cosmetics" onerror="this.src='https://via.placeholder.com/300x200?text=Orthodontics'">
                        <div class="appointment-type-content">
                            <h5>Cosmetics Dentistry</h5>
                            <p>Price: ₱700.00</p>
                        </div>
                    </div>
                </div>