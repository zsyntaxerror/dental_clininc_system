<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'patient') {
    header("Location: login.php");
    exit();
}

$conn = new mysqli('localhost', 'root', '', 'dental');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


// Fetch patient information
$p_id = $_SESSION['p_id']; // This should be set during login
$stmt = $conn->prepare("SELECT p_name FROM patients WHERE p_id = ?");
$stmt->bind_param("i", $p_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $patient_data = $result->fetch_assoc();
    $patient_name = $patient_data['p_name'];
} else {
    $patient_name = "Patient"; // Default value if name not found
}
$stmt->close();
// Get patient ID from session
$patient_id = $_SESSION['p_id'] ?? 1;

// Process appointment cancellation
if (isset($_POST['cancel_appointment'])) {
    $app_id = $_POST['app_id'];
    
    $cancel_query = $conn->prepare("UPDATE appointments SET status = 'Cancelled' WHERE app_id = ? AND p_id = ?");
    $cancel_query->bind_param("ii", $app_id, $p_id);
    
    // Rest of the code...

    
    if ($cancel_query->execute()) {
        $_SESSION['message'] = "Appointment successfully cancelled.";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Failed to cancel appointment. Please try again.";
        $_SESSION['message_type'] = "danger";
    }
    
    $cancel_query->close();
    header("Location: appointment_summary.php");
    exit();
}
// Process appointment rescheduling
if (isset($_POST['reschedule_appointment'])) {
    $app_id = $_POST['app_id'];
    // Redirect to the rescheduling page with the appointment ID
    header("Location: reschedule.php?id=".$app_id);
    exit();
}
// Fetch all appointments for the current patient
$stmt = $conn->prepare("SELECT a.app_id, a.date, a.time, a.status, 
                        d.doc_name, a.p_type AS service_type,
                        a.sub_service
                        FROM appointments a 
                        JOIN doctors d ON a.doc_id = d.doc_id 
                        WHERE a.p_id = ?
                        ORDER BY a.date DESC");
$stmt->bind_param("i", $p_id);
$stmt->execute();
$result = $stmt->get_result();
$appointments = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Count appointments
$upcoming_count = 0;
$completed_count = 0;
$cancelled_count = 0;

foreach ($appointments as $app) {
    if ($app['status'] == 'Completed') {
        $completed_count++;
    } else if ($app['status'] == 'Cancelled') {
        $cancelled_count++;
    } else {
        // Both Pending and Scheduled are considered upcoming
        $upcoming_count++;
    }
}

$total_count = count($appointments);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Summary</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        
        .sidebar {
            background-color: white;
            height: 100vh;
            position: sticky;
            top: 0;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        
        .sidebar .nav-link {
            color: #333;
            padding: 10px 15px;
            border-radius: 5px;
            margin-bottom: 5px;
            display: flex;
            align-items: center;
        }
        
        .sidebar .nav-link.active {
            background-color: #e9f0ff;
            color: #0d6efd;
            font-weight: 500;
        }
        
        .sidebar .nav-link:hover {
            background-color: #f0f0f0;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            padding: 20px;
        }
        
        .profile-section {
            text-align: center;
            padding: 20px 10px;
            border-bottom: 1px solid #eee;
            margin-bottom: 20px;
        }
        
        .profile-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background-color: #e9ecef;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
        }
        
        .profile-avatar i {
            font-size: 40px;
            color: #6c757d;
        }
        
        .log-out-btn {
            background-color: #e9f0ff;
            color: #0d6efd;
            border: none;
            border-radius: 5px;
            padding: 8px 15px;
            width: 100%;
            margin-bottom: 20px;
            font-weight: 500;
        }
        
        .log-out-btn:hover {
            background-color: #d8e5ff;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .date-display {
            text-align: right;
        }
        
        .back-btn {
            background-color: #e9f0ff;
            color: #0d6efd;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
        }
        
        .back-btn:hover {
            background-color: #d8e5ff;
        }
        
        .appointment-card {
            background-color: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
            margin-bottom: 20px;
            padding: 20px;
        }
        
        .appointment-action-btn {
            padding: 6px 12px;
            border-radius: 5px;
            border: none;
            margin-right: 5px;
        }
        
        .reschedule-btn {
            background-color: #e9f0ff;
            color: #0d6efd;
        }
        
        .cancel-btn {
            background-color: #ffe9e9;
            color: #dc3545;
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .status-confirmed {
            background-color: #d1e7dd;
            color: #0f5132;
        }
        
        .status-pending {
            background-color: #fff3cd;
            color: #856404;
        }
        
        .status-cancelled {
            background-color: #f8d7da;
            color: #721c24;
        }
        
        .status-completed {
            background-color: #cfe2ff;
            color: #084298;
        }
        
        .summary-stats {
            background-color: white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
        }
        
        .stat-card {
            text-align: center;
            padding: 15px;
            background-color: #f8f9fa;
            border-radius: 8px;
        }
        
        .filter-tabs {
            margin-bottom: 20px;
        }
        
        .filter-tabs .nav-link {
            color: #6c757d;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
        }
        
        .filter-tabs .nav-link.active {
            background-color: #e9f0ff;
            color: #0d6efd;
            font-weight: 500;
        }
        
        .alert {
            margin-bottom: 20px;
        }
           /* Add styling for Pending status */
    .status-pending {
        background-color: #ffc107;
        color: #212529;
    }
    
    /* Existing styles for other statuses */
    .status-scheduled {
        background-color: #0d6efd;
        color: white;
    }
    
    .status-completed {
        background-color: #198754;
        color: white;
    }
    
    .status-cancelled {
        background-color: #dc3545;
        color: white;
    }
    
    .status-badge {
        padding: 5px 10px;
        border-radius: 4px;
        font-size: 0.8em;
        font-weight: bold;
    }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 p-0 sidebar">
                <div class="profile-section">
                    <div class="profile-avatar">
                        <i class="bi bi-person"></i>
                    </div>
                    <h5 class="mb-1"><?php echo htmlspecialchars($patient_name); ?></h5>
                    <p class="text-muted small mb-3"><?php echo htmlspecialchars($_SESSION['user']); ?></p>                  
                    <button class="log-out-btn" onclick="location.href='../logout.php'">Log out</button>
                </div>
                <div class="px-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a href="dashboard.php" class="nav-link">
                                <i class="bi bi-house"></i> Home
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="doctors.php" class="nav-link">
                                <i class="bi bi-people"></i> All Dentist
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="schedule.php" class="nav-link">
                                <i class="bi bi-calendar-check"></i> Schedule Appointment
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="appointment_summary.php" class="nav-link active">
                                <i class="bi bi-bookmark"></i> My Bookings
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="settings.php" class="nav-link">
                                <i class="bi bi-gear"></i> Settings
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content">
                <div class="header">
                    <h3>My Bookings History</h3>
                    <div class="date-display">
                        <p class="mb-0 text-muted">Today's Date</p>
                        <h5><?php echo date('Y-m-d'); ?></h5>
                    </div>
                </div>

                <!-- Display message if any -->
                <?php if (isset($_SESSION['message'])): ?>
                    <div class="alert alert-<?php echo $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
                        <?php echo $_SESSION['message']; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php 
                    unset($_SESSION['message']);
                    unset($_SESSION['message_type']);
                    ?>
                <?php endif; ?>

                <!-- Summary Stats -->
                <div class="summary-stats">
                    <h4 class="mb-3">Appointments Summary</h4>
                    <div class="row">
                        <div class="col-md-3">
                            <div class="stat-card">
                                <h2><?php echo $total_count; ?></h2>
                                <p class="mb-0">Total Bookings</p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="stat-card">
                                <h2><?php echo $upcoming_count; ?></h2>
                                <p class="mb-0">Upcoming</p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="stat-card">
                                <h2><?php echo $completed_count; ?></h2>
                                <p class="mb-0">Completed</p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="stat-card">
                                <h2><?php echo $cancelled_count; ?></h2>
                                <p class="mb-0">Cancelled</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Filter Tabs -->
                <ul class="nav filter-tabs" id="appointmentTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="all-tab" data-bs-toggle="tab" data-bs-target="#all" type="button" role="tab">All Appointments</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="upcoming-tab" data-bs-toggle="tab" data-bs-target="#upcoming" type="button" role="tab">Upcoming</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="completed-tab" data-bs-toggle="tab" data-bs-target="#completed" type="button" role="tab">Completed</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="cancelled-tab" data-bs-toggle="tab" data-bs-target="#cancelled" type="button" role="tab">Cancelled</button>
                    </li>
                </ul>

                <!-- Tab Content -->
                <div class="tab-content" id="appointmentTabContent">
                    <!-- All Appointments Tab -->
                    <div class="tab-pane fade show active" id="all" role="tabpanel">
                        <?php if (count($appointments) > 0): ?>
                            <?php foreach ($appointments as $appointment): ?>
                                <div class="appointment-card">
                                    <div class="d-flex justify-content-between align-items-center mb-3">
                                        <div>
                                            <h5 class="mb-0"><?php echo htmlspecialchars($appointment['doc_name']); ?></h5>
                                            <p class="text-muted mb-0">Service: <?php echo htmlspecialchars($appointment['service_type']); ?> - <?php echo htmlspecialchars($appointment['sub_service'] ?? ''); ?></p>
                                        </div>
                                        <span class="status-badge <?php echo 'status-' . strtolower($appointment['status']); ?>">
                                            <?php echo htmlspecialchars($appointment['status']); ?>
                                        </span>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <p class="mb-0"><strong>Date:</strong> <?php echo htmlspecialchars($appointment['date']); ?></p>
                                            <p class="mb-0"><strong>Time:</strong> <?php echo htmlspecialchars($appointment['time']); ?></p>
                                            <p class="mb-0"><strong>Appointment ID:</strong> <?php echo htmlspecialchars($appointment['app_id']); ?></p>
                                        </div>
                                        <div>
                                        <?php if ($appointment['status'] == 'Pending'): ?>
    <form method="post" style="display: inline-block;" onsubmit="return confirm('Are you sure you want to cancel this appointment?');">
        <input type="hidden" name="app_id" value="<?php echo $appointment['app_id']; ?>">
        <button type="submit" name="cancel_appointment" class="appointment-action-btn cancel-btn">
            <i class="bi bi-x-circle"></i> Cancel
        </button>
    </form>
<?php endif; ?>

                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p class="text-center">No appointments found.</p>
                        <?php endif; ?>
                    </div>

                    <!-- Upcoming Tab -->
                    <div class="tab-pane fade" id="upcoming" role="tabpanel">
                        <?php 
                        $has_upcoming = false;
                        foreach ($appointments as $appointment): 
                            if ($appointment['status'] != 'completed' && $appointment['status'] != 'cancelled'):
                                $has_upcoming = true;
                        ?>
                            <div class="appointment-card">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <div>
                                        <h5 class="mb-0"><?php echo htmlspecialchars($appointment['doc_name']); ?></h5>
                                        <p class="text-muted mb-0">Service: <?php echo htmlspecialchars($appointment['service_type']); ?> - <?php echo htmlspecialchars($appointment['sub_service'] ?? ''); ?></p>
                                    </div>
                                    <span class="status-badge <?php echo 'status-' . strtolower($appointment['status']); ?>">
                                        <?php echo htmlspecialchars($appointment['status']); ?>
                                    </span>
                                </div>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <p class="mb-0"><strong>Date:</strong> <?php echo htmlspecialchars($appointment['date']); ?></p>
                                        <p class="mb-0"><strong>Time:</strong> <?php echo htmlspecialchars($appointment['time']); ?></p>
                                        <p class="mb-0"><strong>Appointment ID:</strong> <?php echo htmlspecialchars($appointment['app_id']); ?></p>
                                    </div>
                                    <div>
                                        <form method="post" style="display: inline-block;" onsubmit="return confirm('Are you sure you want to cancel this appointment?');">
                                            <input type="hidden" name="app_id" value="<?php echo $appointment['app_id']; ?>">
                                            <button type="submit" name="cancel_appointment" class="appointment-action-btn cancel-btn">
                                                <i class="bi bi-x-circle"></i> Cancel
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php 
                            endif;
                        endforeach; 
                        
                        if (!$has_upcoming):
                        ?>
                            <p class="text-center">No upcoming appointments found.</p>
                        <?php endif; ?>
                    </div>

                    <!-- Completed Tab -->
                    <div class="tab-pane fade" id="completed" role="tabpanel">
                        <?php 
                        $has_completed = false;
                        foreach ($appointments as $appointment): 
                            if ($appointment['status'] == 'completed'):
                                $has_completed = true;
                        ?>
                            <div class="appointment-card">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <div>
                                        <h5 class="mb-0"><?php echo htmlspecialchars($appointment['doc_name']); ?></h5>
                                        <p class="text-muted mb-0">Service: <?php echo htmlspecialchars($appointment['service_type']); ?> - <?php echo htmlspecialchars($appointment['sub_service'] ?? ''); ?></p>
                                    </div>
                                    <span class="status-badge status-completed">
                                        Completed
                                    </span>
                                </div>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <p class="mb-0"><strong>Date:</strong> <?php echo htmlspecialchars($appointment['date']); ?></p>
                                        <p class="mb-0"><strong>Time:</strong> <?php echo htmlspecialchars($appointment['time']); ?></p>
                                        <p class="mb-0"><strong>Appointment ID:</strong> <?php echo htmlspecialchars($appointment['app_id']); ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php 
                            endif;
                        endforeach; 
                        
                        if (!$has_completed):
                        ?>
                            <p class="text-center">No completed appointments found.</p>
                        <?php endif; ?>
                    </div>

                    <!-- Cancelled Tab -->
                    <div class="tab-pane fade" id="cancelled" role="tabpanel">
                        <?php 
                        $has_cancelled = false;
                        foreach ($appointments as $appointment): 
                            if ($appointment['status'] == 'cancelled'):
                                $has_cancelled = true;
                        ?>
                            <div class="appointment-card">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <div>
                                        <h5 class="mb-0"><?php echo htmlspecialchars($appointment['doc_name']); ?></h5>
                                        <p class="text-muted mb-0">Service: <?php echo htmlspecialchars($appointment['service_type']); ?> - <?php echo htmlspecialchars($appointment['sub_service'] ?? ''); ?></p>
                                    </div>
                                    <span class="status-badge status-cancelled">
                                        Cancelled
                                    </span>
                                </div>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <p class="mb-0"><strong>Date:</strong> <?php echo htmlspecialchars($appointment['date']); ?></p>
                                        <p class="mb-0"><strong>Time:</strong> <?php echo htmlspecialchars($appointment['time']); ?></p>
                                        <p class="mb-0"><strong>Appointment ID:</strong> <?php echo htmlspecialchars($appointment['app_id']); ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php 
                            endif;
                        endforeach; 
                        
                        if (!$has_cancelled):
                        ?>
                            <p class="text-center">No cancelled appointments found.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>