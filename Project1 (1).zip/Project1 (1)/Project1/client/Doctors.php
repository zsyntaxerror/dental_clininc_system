<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'patient') {
    header("Location: login.php");
    exit();
}

$conn = new mysqli('localhost', 'root', '', 'dental');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Fetch patient information
$p_id = $_SESSION['p_id']; // This should be set during login
$stmt = $conn->prepare("SELECT p_name FROM patients WHERE p_id = ?");
$stmt->bind_param("i", $p_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $patient_data = $result->fetch_assoc();
    $patient_name = $patient_data['p_name'];
} else {
    $patient_name = "Patient"; // Default value if name not found
}
$stmt->close();

// Fetch all registered doctors
// Fetch all registered doctors with their specialties
// Fetch all registered doctors with their specialties
$stmt = $conn->prepare("
    SELECT d.doc_id, d.doc_name, d.doc_email, s.specialty_name 
    FROM doctors d
    LEFT JOIN specialties s ON d.specialty_id = s.specialty_id
");
$stmt->execute();
$result = $stmt->get_result();
$dentists = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
// Count doctors
$doctor_count = count($dentists);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        
        .sidebar {
            background-color: white;
            height: 100vh;
            position: sticky;
            top: 0;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        
        .sidebar .nav-link {
            color: #333;
            padding: 10px 15px;
            border-radius: 5px;
            margin-bottom: 5px;
            display: flex;
            align-items: center;
        }
        
        .sidebar .nav-link.active {
            background-color: #e9f0ff;
            color: #0d6efd;
            font-weight: 500;
        }
        
        .sidebar .nav-link:hover {
            background-color: #f0f0f0;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            padding: 20px;
        }
        
        .profile-section {
            text-align: center;
            padding: 20px 10px;
            border-bottom: 1px solid #eee;
            margin-bottom: 20px;
        }
        
        .profile-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background-color: #e9ecef;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
        }
        
        .profile-avatar i {
            font-size: 40px;
            color: #6c757d;
        }
        
        .log-out-btn {
            background-color: #e9f0ff;
            color: #0d6efd;
            border: none;
            border-radius: 5px;
            padding: 8px 15px;
            width: 100%;
            margin-bottom: 20px;
            font-weight: 500;
        }
        
        .log-out-btn:hover {
            background-color: #d8e5ff;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .date-display {
            text-align: right;
        }
        
        .search-bar {
            margin-bottom: 20px;
        }
        
        .search-container {
            position: relative;
            display: flex;
        }
        
        .search-input {
            border-radius: 5px;
            border: 1px solid #ced4da;
            padding: 10px 15px;
            flex-grow: 1;
        }
        
        .search-btn {
            margin-left: 10px;
        }
        
        .back-btn {
            background-color: #e9f0ff;
            color: #0d6efd;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
        }
        
        .back-btn:hover {
            background-color: #d8e5ff;
        }
        
        .doctors-table {
            background-color: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
        }
        
        .doctors-table th {
            background-color: #f8f9fa;
            font-weight: 500;
            padding: 15px;
        }
        
        .doctors-table td {
            padding: 15px;
            vertical-align: middle;
        }
        
        .action-btn {
            padding: 6px 12px;
            border-radius: 5px;
            border: none;
            color: white;
            font-size: 14px;
        }
        
        .view-btn {
            background-color: #e9f0ff;
            color: #0d6efd;
        }
        
        .sessions-btn {
            background-color: #e9f0ff;
            color: #0d6efd;
            margin-left: 5px;
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 p-0 sidebar">
                <div class="profile-section">
                    <div class="profile-avatar">
                        <i class="bi bi-person"></i>
                    </div>
                    <h5 class="mb-1"><?php echo htmlspecialchars($patient_name); ?></h5>
                    <p class="text-muted small mb-3"><?php echo htmlspecialchars($_SESSION['user']); ?></p>
                    <button class="log-out-btn" onclick="location.href='logout.php'">Log out</button>
                </div>
                <div class="px-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a href="dashboard.php" class="nav-link">
                                <i class="bi bi-house"></i> Home
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="Doctors.php" class="nav-link active">
                                <i class="bi bi-people"></i> All Dentist
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="Schedule.php" class="nav-link">
                                <i class="bi bi-calendar-check"></i> Schedule Appointment
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="appointment_summary.php" class="nav-link">
                                <i class="bi bi-bookmark"></i> My Bookings
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="settings.php" class="nav-link">
                                <i class="bi bi-gear"></i> Settings
                            </a>
                        </li>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content">
                <div class="header">
                    <a href="index.php" class="back-btn">
                        <i class="bi bi-arrow-left me-2"></i> Back
                    </a>
                    <div class="date-display">
                        <p class="mb-0 text-muted">Today's Date</p>
                        <h5><?php echo date('Y-m-d'); ?></h5>
                    </div>
                </div>

                <!-- Search Bar -->
               
<div class="search-bar">
    <div class="search-container">
        <input type="text" class="form-control search-input" placeholder="Search by doctor name, email or specialty">
        <button type="submit" class="btn btn-primary search-btn">Search</button>
    </div>
</div>
                

                <!-- Doctors List -->
                <h5 class="mb-3">All Doctors (<?php echo $doctor_count; ?>)</h5>
                
                <div class="table-responsive doctors-table">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Doctor Name</th>
                                <th>Email</th>
                                <th>Specialties</th>
                                <th>Events</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($dentists as $doctor): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($doctor['doc_name']); ?></td>
                                <td><?php echo htmlspecialchars($doctor['doc_email']); ?></td>
                                <td>
                                     <?php echo htmlspecialchars($doctor['specialty_name'] ?? 'Not Assigned'); ?>
                                </td>
                                <td>
                                    <button class="action-btn view-btn">
                                        <i class="bi bi-eye"></i> View
                                    </button>
                                    <button class="action-btn sessions-btn">
                                        <i class="bi bi-calendar"></i> Sessions
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>

                            <?php if (count($dentists) == 0): ?>
                            <tr>
                                <td colspan="4" class="text-center py-4">No doctors found</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
</body> 

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Get the search form, input and table
    const searchForm = document.querySelector('.search-container');
    const searchInput = document.querySelector('.search-input');
    const dentistTable = document.querySelector('.doctors-table table');
    const dentistRows = dentistTable.querySelectorAll('tbody tr');
    
    // Add event listener for the search form submission
    searchForm.addEventListener('submit', function(e) {
        e.preventDefault(); // Prevent the form from submitting traditionally
        
        const searchTerm = searchInput.value.toLowerCase().trim();
        searchDentists(searchTerm);
    });
    
    // Add event listener for real-time search as user types
    searchInput.addEventListener('keyup', function() {
        const searchTerm = searchInput.value.toLowerCase().trim();
        searchDentists(searchTerm);
    });
    
    // Function to filter dentists based on search term
    function searchDentists(searchTerm) {
        let foundResults = false;
        
        // Loop through all rows and hide/show based on search
        dentistRows.forEach(function(row) {
            const dentistName = row.cells[0].textContent.toLowerCase();
            const dentistEmail = row.cells[1].textContent.toLowerCase();
            const dentistSpecialty = row.cells[2].textContent.toLowerCase();
            
            // Check if any of the fields contain the search term
            if (dentistName.includes(searchTerm) || 
                dentistEmail.includes(searchTerm) || 
                dentistSpecialty.includes(searchTerm)) {
                row.style.display = '';
                foundResults = true;
            } else {
                row.style.display = 'none';
            }
        });
        
        // Check if no results were found
        const noResultsRow = dentistTable.querySelector('.no-results');
        
        // Remove existing "no results" message if it exists
        if (noResultsRow) {
            noResultsRow.remove();
        }
        
        // Show "no results" message if nothing found
        if (!foundResults && searchTerm !== '') {
            const tbody = dentistTable.querySelector('tbody');
            const messageRow = document.createElement('tr');
            messageRow.className = 'no-results';
            
            const messageCell = document.createElement('td');
            messageCell.setAttribute('colspan', '4');
            messageCell.className = 'text-center py-4';
            messageCell.textContent = 'No dentists found matching "' + searchTerm + '"';
            
            messageRow.appendChild(messageCell);
            tbody.appendChild(messageRow);
        }
    }
});
</script>