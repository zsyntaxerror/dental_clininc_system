<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root"; // Default XAMPP username
$password = ""; // Default XAMPP password
$dbname = "dental"; // Replace with your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'patient') {
    header("Location: login.php");
    exit();
}

// Get patient email from session
$patient_email = $_SESSION['user'];

// Fetch patient details
$patient_query = $conn->prepare("SELECT * FROM patients WHERE p_email = ?");
$patient_query->bind_param("s", $patient_email);
$patient_query->execute();
$patient_result = $patient_query->get_result();

if ($patient_result->num_rows > 0) {
    $patient_data = $patient_result->fetch_assoc();
    $patient_name = $patient_data['p_name'];
    $patient_gender = $patient_data['p_gender'];
    $patient_contact = $patient_data['p_contact'];
    $patient_address = $patient_data['p_address'];
    $patient_dob = $patient_data['p_dob'];
    $patient_age = $patient_data['p_age'];
    $patient_id = $patient_data['p_id'];
} else {
    // Handle case when patient data is not found
    $patient_name = "User";
    $patient_gender = "";
    $patient_contact = "";
    $patient_address = "";
    $patient_dob = "";
    $patient_age = "";
    $patient_id = "";
}
$patient_query->close();

// Handle account settings update
if (isset($_POST['update_account'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $address = $_POST['address'];
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    
    // Verify current password
    $check_password = $conn->prepare("SELECT p_password FROM patients WHERE p_email = ?");
    $check_password->bind_param("s", $patient_email);
    $check_password->execute();
    $password_result = $check_password->get_result();
    $password_data = $password_result->fetch_assoc();
    
    if (password_verify($current_password, $password_data['p_password'])) {
        // Password verified, update details
        if (!empty($new_password)) {
            // Update with new password
            $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
            $update_query = $conn->prepare("UPDATE patients SET p_name = ?, p_email = ?, p_contact = ?, p_address = ?, p_password = ? WHERE p_id = ?");
            $update_query->bind_param("sssssi", $name, $email, $contact, $address, $hashed_password, $patient_id);
        } else {
            // Update without changing password
            $update_query = $conn->prepare("UPDATE patients SET p_name = ?, p_email = ?, p_contact = ?, p_address = ? WHERE p_id = ?");
            $update_query->bind_param("ssssi", $name, $email, $contact, $address, $patient_id);
        }
        
        if ($update_query->execute()) {
            // Update session if email changed
            if ($email != $patient_email) {
                $_SESSION['user'] = $email;
            }
            $success_message = "Account details updated successfully!";
            
            // Refresh patient data
            $patient_email = $email;
            $patient_query = $conn->prepare("SELECT * FROM patients WHERE p_email = ?");
            $patient_query->bind_param("s", $patient_email);
            $patient_query->execute();
            $patient_result = $patient_query->get_result();
            $patient_data = $patient_result->fetch_assoc();
            
            $patient_name = $patient_data['p_name'];
            $patient_contact = $patient_data['p_contact'];
            $patient_address = $patient_data['p_address'];
        } else {
            $error_message = "Error updating account: " . $conn->error;
        }
    } else {
        $error_message = "Current password is incorrect.";
    }
}

// Handle account deletion
if (isset($_POST['delete_account'])) {
    $delete_password = $_POST['delete_password'];
    
    // Verify password before deletion
    $check_password = $conn->prepare("SELECT p_password FROM patients WHERE p_email = ?");
    $check_password->bind_param("s", $patient_email);
    $check_password->execute();
    $password_result = $check_password->get_result();
    $password_data = $password_result->fetch_assoc();
    
    if (password_verify($delete_password, $password_data['p_password'])) {
        // Password verified, delete account
        $delete_query = $conn->prepare("DELETE FROM patients WHERE p_id = ?");
        $delete_query->bind_param("i", $patient_id);
        
        if ($delete_query->execute()) {
            // Clear session and redirect to login
            session_destroy();
            header("Location: login.php?msg=account_deleted");
            exit();
        } else {
            $error_message = "Error deleting account: " . $conn->error;
        }
    } else {
        $error_message = "Password is incorrect.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <title>Patient Settings</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        body {
            background-color: #f5f5f5;
        }
        .container {
    display: flex;
    min-height: 100vh;
    width: 100%;
    max-width: 100%;
    padding: 0;
    margin: 0;
}
       
        .sidebar {
            width: 250px;
            background-color: white;
            height: 100vh;
            position: sticky;
            top: 0;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px 0;
        }
        
        .sidebar .nav-link {
            color: #333;
            padding: 12px 20px;
            border-radius: 0;
            margin-bottom: 5px;
            display: flex;
            align-items: center;
            font-size: 15px;
            transition: all 0.2s ease;
        }
        
        .sidebar .nav-link.active {
            background-color: #e6f0ff;
            color: #0d6efd;
            font-weight: 500;
            border-left: 4px solid #0d6efd;
        }
        
        .sidebar .nav-link:hover {
            background-color: #f5f5f5;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
            font-size: 18px;
        }
       
        .main-content {
            flex: 1;
            padding: 20px 30px;
        }
        
        .profile-section {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .profile-image {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background-color: #f0f0f0;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 10px;
        }
        
        .profile-image i {
            font-size: 40px;
            color: #777;
        }
        
        .profile-info {
            text-align: center;
        }
        
        .profile-info h3 {
            margin-bottom: 5px;
            font-size: 18px;
            font-weight: 600;
        }
        
        .profile-info p {
            color: #666;
            font-size: 14px;
        }
        
        .logout-btn {
            background-color: #f0f7ff;
            color: #0d6efd;
            border: none;
            padding: 10px;
            width: 80%;
            margin: 0 auto 20px;
            display: block;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.2s ease;
        }
        
        .logout-btn:hover {
            background-color: #e0f0ff;
        }
        
        .header {
            display: flex;
            align-items: center;
            margin-bottom: 30px;
        }
        
        .back-btn {
            display: flex;
            align-items: center;
            background: none;
            border: none;
            color: #0d6efd;
            font-size: 15px;
            padding: 0;
            cursor: pointer;
            margin-right: 15px;
        }
        
        .back-btn i {
            margin-right: 5px;
        }
        
        .header h2 {
            font-size: 24px;
            font-weight: 600;
            margin: 0;
        }
        
        .date-container {
            display: flex;
            align-items: center;
            margin-left: auto;
            background-color: white;
            padding: 8px 15px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        
        .date-container span {
            margin-right: 8px;
            color: #666;
        }
        
        .date-container strong {
            margin-right: 8px;
        }
        
        .settings-card {
            background-color: white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            display: flex;
            align-items: center;
            cursor: pointer;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        
        .settings-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        
        .settings-icon {
            width: 60px;
            height: 60px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 20px;
            flex-shrink: 0;
        }
        
        .settings-card:nth-child(1) .settings-icon {
            background-color: #f0f7ff;
        }
        
        .settings-card:nth-child(2) .settings-icon {
            background-color: #f0f7ff;
        }
        
        .settings-card:nth-child(3) .settings-icon {
            background-color: #fff0f0;
        }
        
        .settings-icon i {
            font-size: 24px;
        }
        
        .settings-card:nth-child(1) .settings-icon i,
        .settings-card:nth-child(2) .settings-icon i {
            color: #0d6efd;
        }
        
        .settings-card:nth-child(3) .settings-icon i {
            color: #ff3b30;
        }
        
        .settings-content {
            flex: 1;
        }
        
        .settings-content h3 {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .settings-card:nth-child(1) .settings-content h3,
        .settings-card:nth-child(2) .settings-content h3 {
            color: #0d6efd;
        }
        
        .settings-card:nth-child(3) .settings-content h3 {
            color: #ff3b30;
        }
        
        .settings-content p {
            color: #666;
            font-size: 14px;
            margin: 0;
        }
        
        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.4);
        }
        
        .modal-content {
            background-color: #fefefe;
            margin: 10% auto;
            padding: 25px;
            border: none;
            width: 90%;
            max-width: 500px;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }
        
        .modal-content h2 {
            margin-top: 0;
            margin-bottom: 20px;
            font-size: 22px;
            font-weight: 600;
        }
        
        .close-btn {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            line-height: 0.8;
        }
        
        .close-btn:hover {
            color: #333;
        }
        
        .form-group {
            margin-bottom: 18px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 6px;
            font-weight: 500;
            font-size: 14px;
            color: #444;
        }
        
        .form-group input {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 15px;
            transition: border 0.2s ease;
        }
        
        .form-group input:focus {
            border-color: #0d6efd;
            outline: none;
        }
        
        .btn {
            padding: 10px 18px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 500;
            font-size: 15px;
            border: none;
            transition: background-color 0.2s ease;
        }
        
        .btn-primary {
            background-color: #0d6efd;
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #0b5ed7;
        }
        
        .btn-cancel {
            background-color: #f0f0f0;
            color: #444;
            margin-right: 10px;
        }
        
        .btn-cancel:hover {
            background-color: #e0e0e0;
        }
        
        .btn-danger {
            background-color: #ff3b30;
            color: white;
        }
        
        .btn-danger:hover {
            background-color: #e53529;
        }
        
        .btn-container {
            display: flex;
            justify-content: flex-end;
            margin-top: 25px;
        }
        
        /* Tab styles for view details */
        .tab-container {
            margin-top: 15px;
        }
        
        .tab-content {
            display: none;
        }
        
        .tab-content.active {
            display: block;
        }
        .date-container {
            text-align: right;
        }
        
        /* Alert styles */
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <div class="profile-section">
                <div class="profile-image">
                    <i class="bi bi-person"></i>
                </div>
                <div class="profile-info">
                <h5 class="mb-1"><?php echo htmlspecialchars($patient_name); ?></h5>
                <p class="text-muted small mb-3"><?php echo htmlspecialchars($_SESSION['user']); ?></p>                   
                </div>
            </div>
            <div class="text-center mb-4">
                <button class="logout-btn">Log out</button>
            </div>
                 <div class="px-3">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a href="../client/dashboard.php" class="nav-link">
                            <i class="bi bi-house"></i> Home
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="../client/Doctors.php" class="nav-link">
                            <i class="bi bi-people"></i> All Dentist
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="../client/schedule.php" class="nav-link">
                            <i class="bi bi-calendar-check"></i> Schedule Sessions
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="../client/appointment_summary.php" class="nav-link">
                            <i class="bi bi-bookmark"></i> My Bookings
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="../client/settings.php" class="nav-link active">
                            <i class="bi bi-gear"></i> Settings
                        </a>
                    </li>
                </ul>
            </div>
       
        </div>
        <div class="main-content">
            <div class="header">
                <a href="../client/dashboard.php" class="back-btn">
                    <i class="bi bi-arrow-left"></i>
                    Back
                </a>
                <h2>Settings</h2>
                <div class="date-container">
                <p class="mb-0 text-muted">Today's Date</p>
                <h5><?php echo date('Y-m-d'); ?></h5>          
                </div>
            </div>
            
            <!-- Display success/error messages -->
            <?php if(isset($success_message)): ?>
                <div class="alert alert-success">
                    <?php echo $success_message; ?>
                </div>
            <?php endif; ?>
            
            <?php if(isset($error_message)): ?>
                <div class="alert alert-danger">
                    <?php echo $error_message; ?>
                </div>
            <?php endif; ?>
            
            <div class="settings-card" id="account-settings-card">
                <div class="settings-icon">
                    <i class="bi bi-person"></i>
                </div>
                <div class="settings-content">
                    <h3>Account Settings</h3>
                    <p>Edit your Account Details & Change Password</p>
                </div>
            </div>
            
            <div class="settings-card" id="view-account-card">
                <div class="settings-icon">
                    <i class="bi bi-eye"></i>
                </div>
                <div class="settings-content">
                    <h3>View Account Details</h3>
                    <p>View Personal Information About Your Account</p>
                </div>
            </div>
            
            <div class="settings-card" id="delete-account-card">
                <div class="settings-icon">
                    <i class="bi bi-trash"></i>
                </div>
                <div class="settings-content">
                    <h3>Delete Account</h3>
                    <p>Will Permanently Remove your Account</p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Account Settings Modal -->
    <div id="accountSettingsModal" class="modal">
        <div class="modal-content">
            <span class="close-btn" onclick="closeModal('accountSettingsModal')">&times;</span>
            <h2>Edit Account Details</h2>
            <form id="accountSettingsForm" method="POST" action="">
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($patient_name); ?>" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($patient_email); ?>" required>
                </div>
                <div class="form-group">
                    <label for="contact">Contact</label>
                    <input type="text" id="contact" name="contact" value="<?php echo htmlspecialchars($patient_contact); ?>" required>
                </div>
                <div class="form-group">
                    <label for="address">Address</label>
                    <input type="text" id="address" name="address" value="<?php echo htmlspecialchars($patient_address); ?>" required>
                </div>
                <div class="form-group">
                    <label for="current_password">Current Password</label>
                    <input type="password" id="current_password" name="current_password" required>
                </div>
                <div class="form-group">
                    <label for="new_password">New Password (leave blank if not changing)</label>
                    <input type="password" id="new_password" name="new_password">
                </div>
                <div class="form-group">
                    <label for="confirm_password">Confirm New Password</label>
                    <input type="password" id="confirm_password" name="confirm_password">
                </div>
                <div class="btn-container">
                    <button type="button" class="btn btn-cancel" onclick="closeModal('accountSettingsModal')">Cancel</button>
                    <button type="submit" name="update_account" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- View Account Details Modal -->
    <div id="viewAccountModal" class="modal">
        <div class="modal-content">
            <span class="close-btn" onclick="closeModal('viewAccountModal')">&times;</span>
            <h2>Account Details</h2>
            <div class="tab-container">
                <div class="tab-content active">
                    <div class="form-group">
                        <label>Name</label>
                        <p><?php echo htmlspecialchars($patient_name); ?></p>
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <p><?php echo htmlspecialchars($patient_email); ?></p>
                    </div>
                    <div class="form-group">
                        <label>Contact</label>
                        <p><?php echo htmlspecialchars($patient_contact); ?></p>
                    </div>
                    <div class="form-group">
                        <label>Address</label>
                        <p><?php echo htmlspecialchars($patient_address); ?></p>
                    </div>
                    <div class="form-group">
                        <label>Gender</label>
                        <p><?php echo htmlspecialchars($patient_gender); ?></p>
                    </div>
                    <div class="form-group">
                        <label>Date of Birth</label>
                        <p><?php echo htmlspecialchars($patient_dob); ?></p>
                    </div>
                    <div class="form-group">
                        <label>Age</label>
                        <p><?php echo htmlspecialchars($patient_age); ?></p>
                    </div>
                </div>
            </div>
            <div class="btn-container">
                <button type="button" class="btn btn-primary" onclick="closeModal('viewAccountModal')">Close</button>
            </div>
        </div>
    </div>
    
    <!-- Delete Account Modal -->
    <div id="deleteAccountModal" class="modal">
        <div class="modal-content">
            <span class="close-btn" onclick="closeModal('deleteAccountModal')">&times;</span>
            <h2>Delete Account</h2>
            <p>Are you sure you want to delete your account? This action cannot be undone.</p>
            <form id="deleteAccountForm" method="POST" action="">
                <div class="form-group">
                    <label for="delete_password">Enter your password to confirm</label>
                    <input type="password" id="delete_password" name="delete_password" required>
                </div>
                <div class="btn-container">
                    <button type="button" class="btn btn-cancel" onclick="closeModal('deleteAccountModal')">Cancel</button>
                    <button type="submit" name="delete_account" class="btn btn-danger">Delete Account</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        // Open modal functions
        document.getElementById('account-settings-card').addEventListener('click', function() {
            document.getElementById('accountSettingsModal').style.display = 'block';
        });
        
        document.getElementById('view-account-card').addEventListener('click', function() {
            document.getElementById('viewAccountModal').style.display = 'block';
        });
        
        document.getElementById('delete-account-card').addEventListener('click', function() {
            document.getElementById('deleteAccountModal').style.display = 'block';
        });
        
        // Close modal function
        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            if (event.target.className === 'modal') {
                event.target.style.display = 'none';
            }
        }
        
        // Password confirmation validation
        document.getElementById('accountSettingsForm').addEventListener('submit', function(e) {
            const newPassword = document.getElementById('new_password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (newPassword && newPassword !== confirmPassword) {
                e.preventDefault();
                alert('New passwords do not match!');
            }
        });
        
        // Logout button functionality
        document.querySelector('.logout-btn').addEventListener('click', function() {
            window.location.href = 'logout.php';
        });
        
        // Back button functionality
        document.querySelector('.back-btn').addEventListener('click', function(e) {
            e.preventDefault();
            window.location.href = '../client/dashboard.php';
        });
    </script>
</body>
</html>