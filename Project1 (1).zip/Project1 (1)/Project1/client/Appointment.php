<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'patient') {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "dental");

$p_id = $_SESSION['p_id']; // This should be set during login
$stmt = $conn->prepare("SELECT p_name FROM patients WHERE p_id = ?");
$stmt->bind_param("i", $p_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $patient_data = $result->fetch_assoc();
    $patient_name = $patient_data['p_name'];
} else {
    $patient_name = "Patient"; // Default value if name not found
}
$stmt->close();


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Manager</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/appointment.css">
    <style>
        .content {
            margin-left: 300px; /* Adjust this value to match the width of your sidebar */
        }
    </style>
</head>
<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <nav class="bg-white p-3 shadow-sm vh-100" style="width: 300px; position: fixed;">
    <div class="text-center mb-4">
        <img src="img/teeth.jpg" alt="" class="w-50">
        <h5 class="fw-bold mt-2">WELCOME!</h5>
        <?php echo isset($_SESSION['user_email']) ? htmlspecialchars($_SESSION['user_email']) : 'No email found'; ?>
    </div>
    <button class="btn btn-primary w-100 mb-3" onclick="location.href='logout.php'">Log out</button>
    <ul class="nav flex-column">
        <li class="nav-item"><a href="dashboard.php" class="nav-link text-black">Dashboard</a></li>
        <li class="nav-item"><a href="Doctors.php" class="nav-link text-black">Dentist</a></li>
        <li class="nav-item"><a href="schedule.php" class="nav-link text-black">Schedule</a></li>
        <li class="nav-item"><a href="Appointment.php" class="nav-link text-black">Appointment</a></li>
        <li class="nav-item"><a href="patient.php" class="nav-link text-black">Patients</a></li>
    </ul>
</nav>

        <main class="content p-4">
            <div class="d-flex justify-content-between align-items-center">
                <input type="text" class="form-control me-2" placeholder="Search Doctor name or Email">
                <button class="btn btn-primary">Search</button>
            </div>
            <h2 class="mt-4">Appointment Manager</h2>
            <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addAppointmentModal">+ Add New</button>
            <p>All Sessions</p>

            <!-- Add Appointment Modal -->
            <div class="modal fade" id="addAppointmentModal" tabindex="-1" aria-labelledby="addAppointmentModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="addAppointmentModalLabel">Add New Appointment</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form id="addAppointmentForm">
                                <div class="mb-3">
                                    <label for="patientName" class="form-label">Patient Name</label>
                                    <input type="text" class="form-control" id="patientName" name="patientName" required>
                                </div>
                                <div class="mb-3">
                                    <label for="doctorName" class="form-label">Denstist</label>
                                    <input type="text" class="form-control" id="dentistName" name="dentistName" required>
                                </div>
                                <div class="mb-3">
                                    <label for="appointmentDate" class="form-label">Appointment Date</label>
                                    <input type="date" class="form-control" id="appointmentDate" name="appointmentDate" required>
                                </div>
                                <div class="mb-3">
                                    <label for="status" class="form-label">Status</label>
                                    <select class="form-select" id="status" name="status" required>
                                        <option value="Scheduled">Scheduled</option>
                                        <option value="Completed">Completed</option>
                                        <option value="Cancelled">Cancelled</option>
                                        <option value="Pending">Pending</option>
                                    </select>
                                </div>
                                <button type="submit" class="btn btn-primary">Add Appointment</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <script>
                document.getElementById('addAppointmentForm').addEventListener('submit', function(event) {
                    event.preventDefault();
                    const formData = new FormData(this);

                    fetch('add_appointment.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            const newRow = document.createElement('tr');
                            newRow.innerHTML = `
                                <td>${data.appointment_number}</td>
                                <td>${data.patient_name}</td>
                                <td>${data.dentist}</td>
                                <td>${data.appointment_date}</td>
                                <td>${data.status}</td>
                                <td>
                                    <button class="btn btn-primary">Done</button>
                                    <a href="cancel_appointment.php?id=${data.appointment_number}" class="btn btn-danger" onclick="return confirm('Are you sure you want to cancel this appointment?');">Cancel</a>
                                </td>
                            `;
                            document.querySelector('table tbody').appendChild(newRow);
                            document.getElementById('addAppointmentForm').reset();
                            const addAppointmentModal = new bootstrap.Modal(document.getElementById('addAppointmentModal'));
                            addAppointmentModal.hide();
                        } else {
                            alert('Failed to add appointment');
                        }
                    })
                    .catch(error => console.error('Error:', error));
                });
            </script>

            <div class="d-flex">
                <label class="me-2">Date:</label>
                <input type="date" class="form-control me-2">
                <label class="me-2">Doctor:</label>
                <select class="form-select">
                    <option selected>Choose Dentist Name from the list</option>
                </select>
                <button class="btn btn-primary ms-2">Filter</button>
            </div>

            <table class="table mt-4">
                <thead>
                    <tr>
                        <th>Patient Name</th>
                        <th>Appointment Number</th>
                        <th>Dentist</th>
                        <th>Appointment Date</th>
                        <th>Type of Appointment</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT p.p_name AS patient_name, a.app_id AS appointment_no, d.doc_name AS doctor, a.date AS appointment_date, p_type
                        FROM appointments a
                        JOIN patients p ON a.p_id = p.p_id
                        JOIN doctors d ON a.doc_id = d.doc_id";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo '<tr id="appointment-' . htmlspecialchars($row['appointment_no']) . '">';
                            echo "<td>" . htmlspecialchars($row['p_name']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['appointment_no']) . "</td>";
                            echo "<td>" . (!empty($row['doctor']) ? htmlspecialchars($row['doctor']) : 'No Dentist Assigned') . "</td>";
                            echo "<td>" . (!empty($row['appointment_date']) ? htmlspecialchars($row['appointment_date']) : 'Not Scheduled') . "</td>";
                            echo "<td>" . htmlspecialchars($row['status']) . "</td>";
                            echo '<td>
                                    <button class="btn btn-primary">Done</button>
                                    <a href="cancel_appointment.php?id=' . htmlspecialchars($row['appointment_no']) . '" 
                                       class="btn btn-danger"
                                       onclick="return confirm(\'Are you sure you want to cancel this appointment?\');">
                                       Cancel
                                    </a>
                                 </td>';
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='6' class='text-center'>No Appointments Found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </main>
    </div>
</body>
</html>
