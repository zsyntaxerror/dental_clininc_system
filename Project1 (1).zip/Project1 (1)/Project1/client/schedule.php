
<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'patient') {
    header("Location: login.php");
    exit();
}

$conn = new mysqli('localhost', 'root', '', 'dental');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Fetch patient information
$p_id = $_SESSION['p_id']; // This should be set during login
$stmt = $conn->prepare("SELECT p_name FROM patients WHERE p_id = ?");
$stmt->bind_param("i", $p_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $patient_data = $result->fetch_assoc();
    $patient_name = $patient_data['p_name'];
} else {
    $patient_name = "Patient"; // Default value if name not found
}
$stmt->close();

// Define appointment types with their sub-services
$appointmentTypes = [
    'consultation' => [
        'name' => 'Consultation & Diagnosis',
        'price' => 'P100.00',
        'services' => [
            'initial_consultation' => 'Initial Consultation',
            'follow_up' => 'Follow-up Consultation',
            'treatment_planning' => 'Treatment Planning',
            'x_ray_diagnostic' => 'X-Ray Diagnostic'
        ]
    ],
    'restorative' => [
        'name' => 'Restorative Treatment',
        'price' => 'P500.00',
        'services' => [
            'fillings' => 'Dental Fillings',
            'crowns' => 'Dental Crowns',
            'bridges' => 'Dental Bridges',
            'implants' => 'Dental Implants'
        ]
    ],
    'pediatric' => [
        'name' => 'Pediatric Dentistry',
        'price' => 'P100.00',
        'services' => [
            'child_exam' => 'Child Dental Examination',
            'fluoride_treatment' => 'Fluoride Treatment',
            'sealants' => 'Dental Sealants',
            'space_maintainers' => 'Space Maintainers'
        ]
    ],
    'routine' => [
        'name' => 'Routine & Preventive Care',
        'price' => 'P1000.00',
        'services' => [
            'dental_cleaning' => 'Dental Cleaning',
            'oral_exam' => 'Oral Examination',
            'scaling' => 'Scaling',
            'polishing' => 'Polishing'
        ]
    ],
    'orthodontics' => [
        'name' => 'Orthodontics',
        'price' => 'P300.00',
        'services' => [
            'braces' => 'Traditional Braces',
            'clear_aligners' => 'Clear Aligners',
            'retainers' => 'Retainers',
            'adjustment' => 'Orthodontic Adjustment'
        ]
    ],
    'endodontics' => [
        'name' => 'Endodontics',
        'price' => 'P400.00',
        'services' => [
            'root_canal' => 'Root Canal Treatment',
            'pulpotomy' => 'Pulpotomy',
            'apicoectomy' => 'Apicoectomy',
            'pulp_capping' => 'Pulp Capping'
        ]
    ],
    'oral_surgery' => [
        'name' => 'Oral Surgery',
        'price' => 'P350.00',
        'services' => [
            'tooth_extraction' => 'Tooth Extraction',
            'wisdom_teeth' => 'Wisdom Teeth Removal',
            'dental_implant_surgery' => 'Dental Implant Surgery',
            'jaw_surgery' => 'Jaw Surgery'
        ]
    ],
    'cleaning' => [
        'name' => 'Cleaning',
        'price' => 'P350.00',
        'services' => [
            'regular_cleaning' => 'Regular Cleaning',
            'deep_cleaning' => 'Deep Cleaning',
            'scaling_root_planing' => 'Scaling and Root Planing',
            'periodontal_maintenance' => 'Periodontal Maintenance'
        ]
    ]
];
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Filter appointment types based on search
$filteredAppointmentTypes = $appointmentTypes;
if (!empty($search)) {
    $filteredAppointmentTypes = array_filter($appointmentTypes, function($type) use ($search) {
        // Case-insensitive search in appointment type name
        return stripos($type['name'], $search) !== false;
    });
}


// Fetch all appointments for the current patient
$patient_id = $_SESSION['patient_id'] ?? 1; // Use session patient_id if available, otherwise default to 1 for testing
$stmt = $conn->prepare("SELECT a.app_id, a.date, a.time, a.p_type AS status, 
                                d.doc_name, a.p_type AS service_type 
                                FROM appointments a 
                                JOIN doctors d ON a.doc_id = d.doc_id 
                                WHERE a.p_id = ?
                                ORDER BY a.date DESC");
$stmt->bind_param("i", $p_id);
$stmt->execute();
$result = $stmt->get_result();
$appointments = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Fetch all doctors for the dropdown
$doctors_query = "SELECT doc_id, doc_name, specialty_id FROM doctors";
$doctors_result = $conn->query($doctors_query);
$doctors = [];
if ($doctors_result->num_rows > 0) {
    while ($row = $doctors_result->fetch_assoc()) {
        $doctors[] = $row;
    }
}

$conn->close();

// Count appointments
$appointment_count = count($appointments);

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Appointments</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        
        .sidebar {
            background-color: white;
            height: 100vh;
            position: sticky;
            top: 0;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        
        .sidebar .nav-link {
            color: #333;
            padding: 10px 15px;
            border-radius: 5px;
            margin-bottom: 5px;
            display: flex;
            align-items: center;
        }
        
        .sidebar .nav-link.active {
            background-color: #e9f0ff;
            color: #0d6efd;
            font-weight: 500;
        }
        
        .sidebar .nav-link:hover {
            background-color: #f0f0f0;
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            padding: 20px;
        }
        
        .profile-section {
            text-align: center;
            padding: 20px 10px;
            border-bottom: 1px solid #eee;
            margin-bottom: 20px;
        }
        
        .profile-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background-color: #e9ecef;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
        }
        
        .profile-avatar i {
            font-size: 40px;
            color: #6c757d;
        }
        
        .log-out-btn {
            background-color: #e9f0ff;
            color: #0d6efd;
            border: none;
            border-radius: 5px;
            padding: 8px 15px;
            width: 100%;
            margin-bottom: 20px;
            font-weight: 500;
        }
        
        .log-out-btn:hover {
            background-color: #d8e5ff;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .date-display {
            text-align: right;
        }
        
        .search-bar {
            margin-bottom: 20px;
        }
        
        .search-container {
            position: relative;
            display: flex;
        }
        
        .search-input {
            border-radius: 5px;
            border: 1px solid #ced4da;
            padding: 10px 15px;
            flex-grow: 1;
        }
        
        .search-btn {
            margin-left: 10px;
        }
        
        .back-btn {
            background-color: #e9f0ff;
            color: #0d6efd;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
        }
        
        .back-btn:hover {
            background-color: #d8e5ff;
        }
        
        .appointment-card {
            background-color: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
            margin-bottom: 20px;
            padding: 20px;
        }
        
        .appointment-action-btn {
            padding: 6px 12px;
            border-radius: 5px;
            border: none;
            margin-right: 5px;
        }
        
        .reschedule-btn {
            background-color: #e9f0ff;
            color: #0d6efd;
        }
        
        .cancel-btn {
            background-color: #ffe9e9;
            color: #dc3545;
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .status-confirmed {
            background-color: #d1e7dd;
            color: #0f5132;
        }
        
        .status-pending {
            background-color: #fff3cd;
            color: #856404;
        }
        
        .status-cancelled {
            background-color: #f8d7da;
            color: #721c24;
        }
        
        .status-completed {
            background-color: #cfe2ff;
            color: #084298;
        }
        
        /* Styles for appointment types */
        .appointment-types {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .appointment-type-card {
            background-color: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
            width: calc(25% - 15px);
            transition: transform 0.3s ease;
        }
        
        .appointment-type-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .appointment-type-card img {
            width: 100%;
            height: 160px;
            object-fit: cover;
        }
        
        .appointment-type-content {
            padding: 15px;
            text-align: center;
        }
        
        .appointment-type-content h5 {
            margin-bottom: 10px;
            font-weight: 500;
        }
        
        .appointment-type-content p {
            color: #6c757d;
            margin-bottom: 0;
        }
        
        .schedule-btn {
            background-color: #0d6efd;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            width: 100%;
            margin-top: 20px;
            font-weight: 500;
        }
        
        .schedule-btn:hover {
            background-color: #0b5ed7;
        }
        
        @media (max-width: 992px) {
            .appointment-type-card {
                width: calc(50% - 10px);
            }
        }
        
        @media (max-width: 576px) {
            .appointment-type-card {
                width: 100%;
            }
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 p-0 sidebar">
            <div class="profile-section">
        <div class="profile-avatar">
        <i class="bi bi-person"></i>
        </div>
        <h5 class="mb-1"><?php echo htmlspecialchars($patient_name); ?></h5>
        <p class="text-muted small mb-3"><?php echo htmlspecialchars($_SESSION['user']); ?></p>
        <button class="log-out-btn" onclick="location.href='../login.php'">Log out</button>
        </div>
                
                <div class="px-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a href="dashboard.php" class="nav-link">
                                <i class="bi bi-house"></i> Home
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="doctors.php" class="nav-link">
                                <i class="bi bi-people"></i> All Dentist
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="schedule.php" class="nav-link">
                                <i class="bi bi-calendar-check"></i> Schedule Appointment
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="appointment_summary.php" class="nav-link active">
                                <i class="bi bi-bookmark"></i> My Bookings
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="settings.php" class="nav-link">
                                <i class="bi bi-gear"></i> Settings
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content">
                <div class="header">
                    <a href="index.php" class="back-btn">
                        <i class="bi bi-arrow-left me-2"></i> Back
                    </a>
                    <div class="date-display">
                        <p class="mb-0 text-muted">Today's Date</p>
                        <h5><?php echo date('Y-m-d'); ?></h5>
                    </div>
                </div>

                 <!-- Search Bar -->
                <div class="search-bar">
                     <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="GET" class="search-container">
                         <input type="text" name="search" class="form-control search-input" placeholder="Search appointment types..."  value="<?php echo htmlspecialchars($search ?? ''); ?>">
                                 <button type="submit" class="btn btn-primary search-btn">Search</button>
                                 <?php if (!empty($search)): ?>
                 <a href="<?php echo $_SERVER['PHP_SELF']; ?>" class="btn btn-secondary ms-2">Clear</a>
                 <?php endif; ?>
         </form>
    </div>
                

<!-- Types of Appointments -->
<h4 class="mb-3">Types of Appointments</h4>

<div class="appointment-types">
    <?php if (empty($filteredAppointmentTypes)): ?>
        <div class="alert alert-info w-100">
            No appointment types found matching "<?php echo htmlspecialchars($search); ?>". 
            <a href="schedule.php">Show all appointment types</a>
        </div>
    <?php else: ?>
        <?php 
        // Fetch doctors with their specialties
        $conn = new mysqli('localhost', 'root', '', 'dental');
        $doctors_by_specialty = [];
        $doctor_query = "SELECT d.doc_id, d.doc_name, d.specialty_id, s.specialty_name 
                        FROM doctors d 
                        JOIN specialties s ON d.specialty_id = s.specialty_id";
        $doctor_result = $conn->query($doctor_query);
        if ($doctor_result->num_rows > 0) {
            while ($doc = $doctor_result->fetch_assoc()) {
                if (!isset($doctors_by_specialty[$doc['specialty_id']])) {
                    $doctors_by_specialty[$doc['specialty_id']] = [];
                }
                $doctors_by_specialty[$doc['specialty_id']][] = $doc;
            }
        }
        
        // Map appointment types to specialty IDs
        $specialty_mapping = [
            'consultation' => [1, 10], // General Dentistry, Dental Public Health
            'restorative' => [5], // Prosthodontics
            'pediatric' => [7], // Pediatric Dentistry
            'routine' => [1], // General Dentistry
            'orthodontics' => [2], // Orthodontics
            'endodontics' => [4], // Endodontics
            'oral_surgery' => [6], // Oral Surgery
            'cleaning' => [3, 8] // Periodontics, Oral Pathology
        ];
        ?>
        
        <?php foreach ($filteredAppointmentTypes as $typeKey => $type): ?>
            <div class="appointment-type-card" onclick="openForm('<?php echo $typeKey; ?>')">
                <img src="../img/2.jpeg" alt="<?php echo htmlspecialchars($type['name']); ?>" onerror="this.src='https://via.placeholder.com/300x200?text=<?php echo urlencode($type['name']); ?>'">
                <div class="appointment-type-content">
                    <h5><?php echo htmlspecialchars($type['name']); ?></h5>
                    <p>Price: <?php echo htmlspecialchars($type['price']); ?></p>
                    
                 
                      
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>


<!-- Appointment Form Modal -->
<div id="appointmentFormModal" class="modal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle">Schedule Appointment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
            <form id="appointmentForm" action="book_appointment.php" method="POST">
    <input type="hidden" name="appointment_type" id="appointmentTypeInput">
    <div class="mb-3">
        <label for="subService" class="form-label">Select Service</label>
        <select class="form-select" name="sub_service" id="subService" required>
            <!-- Options will be dynamically populated -->
        </select>
    </div>
    <div class="mb-3">
        <label for="doctorSelect" class="form-label">Select Doctor</label>
        <select class="form-select" name="doctor_id" id="doctorSelect" required>
            <!-- Options will be dynamically populated -->
        </select>
    </div>
    <div class="mb-3">
        <label for="appointmentDate" class="form-label">Select Date</label>
        <input type="date" class="form-control" name="appointment_date" id="appointmentDate" required>
    </div>
    <div class="mb-3">
        <label for="appointmentTime" class="form-label">Select Time</label>
        <input type="time" class="form-control" name="appointment_time" id="appointmentTime" required>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>

            </div>
        </div>
    </div>
</div>

<script>
      const appointmentTypes = <?php echo json_encode($appointmentTypes); ?>;
      const doctors = <?php echo json_encode($doctors); ?>;

      function openForm(typeKey) {
    const modal = new bootstrap.Modal(document.getElementById('appointmentFormModal'));
    const type = appointmentTypes[typeKey];

    document.getElementById('modalTitle').textContent = type.name;
    document.getElementById('appointmentTypeInput').value = typeKey;

    const subServiceSelect = document.getElementById('subService');
    subServiceSelect.innerHTML = '';

    for (const [key, value] of Object.entries(type.services)) {
        const option = document.createElement('option');
        option.value = key;
        option.textContent = value;
        subServiceSelect.appendChild(option);
    }

    // Get specialty IDs for this appointment type
    const specialtyMapping = {
        'consultation': [1, 10], // General Dentistry, Dental Public Health
        'restorative': [5], // Prosthodontics
        'pediatric': [7], // Pediatric Dentistry
        'routine': [1], // General Dentistry
        'orthodontics': [2], // Orthodontics
        'endodontics': [4], // Endodontics
        'oral_surgery': [6], // Oral Surgery
        'cleaning': [3, 8] // Periodontics, Oral Pathology
    };

    // Add doctor selection functionality - filtered by specialty
    const doctorSelect = document.getElementById('doctorSelect');
    doctorSelect.innerHTML = '';
    
    const relevantSpecialties = specialtyMapping[typeKey] || [];
    
    // Only show doctors with relevant specialties
    const specialistDoctors = doctors.filter(doctor => 
        relevantSpecialties.includes(parseInt(doctor.specialty_id))
    );
    
    if (specialistDoctors.length > 0) {
        specialistDoctors.forEach(doctor => {
            const option = document.createElement('option');
            option.value = doctor.doc_id;
            option.textContent = doctor.doc_name;
            doctorSelect.appendChild(option);
        });
    } else {
        // Fallback if no specialists are found
        const option = document.createElement('option');
        option.value = "";
        option.textContent = "No specialists available for this service";
        option.disabled = true;
        option.selected = true;
        doctorSelect.appendChild(option);
    }
    
    modal.show();
}

    
   
</script>

    <!-- Appointments List -->
     <!-- Appointments List -->
<h4 class="mb-3 text-center">My Appointments</h4>
<?php if ($appointment_count > 0): ?>
    <?php foreach ($appointments as $appointment): ?>
        <div class="appointment-card">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <div>
                    <h5 class="mb-0"><?php echo htmlspecialchars($appointment['doc_name']); ?></h5>
                    <p class="text-muted mb-0"><?php echo htmlspecialchars($appointment['service_type']); ?></p>
                </div>
                <span class="status-badge <?php echo 'status-' . strtolower($appointment['status']); ?>">
                    <?php echo htmlspecialchars($appointment['status']); ?>
                </span>
            </div>
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <p class="mb-0"><strong>Date:</strong> <?php echo htmlspecialchars($appointment['date']); ?></p>
                    <p class="mb-0"><strong>Time:</strong> <?php echo htmlspecialchars($appointment['time']); ?></p>
                </div>
                <div>
                    <button class="appointment-action-btn reschedule-btn" onclick="openRescheduleModal(<?php echo $appointment['app_id']; ?>, '<?php echo $appointment['date']; ?>', '<?php echo $appointment['time']; ?>')">Reschedule</button>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
<?php else: ?>
    <p class="text-center">No appointments found.</p>
<?php endif; ?>
  
            </div>
        </div>
    </div>
    
    <!-- Reschedule Modal -->
<div class="modal fade" id="rescheduleModal" tabindex="-1" aria-labelledby="rescheduleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="rescheduleModalLabel">Reschedule Appointment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="rescheduleForm" action="reschedule_appointment.php" method="POST">
                    <input type="hidden" name="appointment_id" id="rescheduleAppointmentId">
                    <div class="mb-3">
                        <label for="rescheduleDate" class="form-label">New Date</label>
                        <input type="date" class="form-control" id="rescheduleDate" name="new_date" required>
                    </div>
                    <div class="mb-3">
                        <label for="rescheduleTime" class="form-label">New Time</label>
                        <input type="time" class="form-control" id="rescheduleTime" name="new_time" required>
                    </div>
                    <div class="d-flex justify-content-end">
                        <button type="button" class="btn btn-secondary me-2" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Confirm Reschedule</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    function openRescheduleModal(appointmentId, currentDate, currentTime) {
        document.getElementById('rescheduleAppointmentId').value = appointmentId;
        
        // Set minimum date to today
        const today = new Date();
        const yyyy = today.getFullYear();
        const mm = String(today.getMonth() + 1).padStart(2, '0');
        const dd = String(today.getDate()).padStart(2, '0');
        const todayFormatted = `${yyyy}-${mm}-${dd}`;
        
        const rescheduleDate = document.getElementById('rescheduleDate');
        rescheduleDate.min = todayFormatted;
        rescheduleDate.value = currentDate;
        
        document.getElementById('rescheduleTime').value = currentTime;
        
        const modal = new bootstrap.Modal(document.getElementById('rescheduleModal'));
        modal.show();
    }
</script>

</body>
</html>