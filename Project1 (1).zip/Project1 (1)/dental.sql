-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 24, 2025 at 01:41 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dental`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `aemail` varchar(255) NOT NULL,
  `apassword` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aemail`, `apassword`) VALUES
('admin@gmail.com', '$2y$10$IfBMQYvAqsNl.WUFSWS82eQxPsE2ymkpoycwSsXmmZF6yqRCY.g8O');

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `app_id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  `doc_id` int(11) NOT NULL,
  `sched_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `p_type` varchar(255) DEFAULT NULL,
  `sub_service` varchar(255) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Scheduled',
  `sched_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`app_id`, `p_id`, `doc_id`, `sched_id`, `date`, `time`, `p_type`, `sub_service`, `status`, `sched_date`) VALUES
(86, 16, 11, 1, '2025-04-03', '13:51:00', 'restorative', 'fillings', 'Completed', NULL),
(87, 17, 8, 1, '2025-03-11', '14:31:00', 'endodontics', 'root_canal', 'Scheduled', NULL),
(88, 13, 10, 1, '2025-03-23', '13:34:00', 'cleaning', 'regular_cleaning', 'Scheduled', NULL),
(89, 14, 8, 1, '2025-03-23', '15:05:00', 'endodontics', 'root_canal', 'Pending', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `billing`
--

CREATE TABLE `billing` (
  `bill_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `app_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `doc_id` int(11) NOT NULL,
  `doc_name` varchar(255) NOT NULL,
  `doc_gender` varchar(10) NOT NULL,
  `doc_email` varchar(255) NOT NULL,
  `doc_contact` varchar(15) NOT NULL,
  `specialty_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`doc_id`, `doc_name`, `doc_gender`, `doc_email`, `doc_contact`, `specialty_id`) VALUES
(1, 'Dr. AB_normal', 'Male', 'Dr_AB_normal@yahoo.com', '09890675489', 1),
(2, 'Dr. Botchok', 'Female', 'Dr_Botchok@yahoo.com', '09067895478', 6),
(7, 'Dr.Grachael', 'Female', 'grace@gmail.com', '09678905590', 10),
(8, 'Dr. John', 'Male', 'j@gmail.com', '09890098712', 4),
(9, 'Dr. Rj', 'Male', 'rj@gmail.com', '09895455612', 6),
(10, 'Dr. jr', 'Female', 'jr@gmail.com', '09008976543', 3),
(11, 'Dr. Earl', 'Male', 'earl@gmail.com', '09087560981', 5),
(12, 'Dr. Baloro', 'Male', 'Baloro@gmail.com', '09087654321', 1),
(13, 'Dr. lim', 'Female', 'lim@gmail.com', '0908954321', 2),
(14, 'Dr. Dre', 'Male', 'dre@gmail.com', '09678905590', 1),
(15, 'Dr.erd', 'Male', 'erd@gmail.com', '09000789543', 9),
(16, 'Dr. boy', 'Male', 'boy@gmail.com', '09078956420', 1),
(17, 'Dr. Sasa', 'Female', 'sa@gmail.com', '09998706543', 2),
(18, 'DR. roblox', 'Male', 'roblox@gmail.com', '09786548976', 6),
(19, 'Dr. Moonton', 'Female', 'moonton@gmail.com', '0980789651', 6),
(20, 'Dr. else', 'Female', 'esla@gmail.com', '09897516728', 7),
(21, 'Dr. anna', 'Female', 'anna@gmail.com', '09089763918', 7),
(22, 'Dr. olaf', 'Male', 'olaf@gmail.com', '09829301982', 3);

-- --------------------------------------------------------

--
-- Table structure for table `doctor_specialties`
--

CREATE TABLE `doctor_specialties` (
  `id` int(11) NOT NULL,
  `doc_id` int(11) DEFAULT NULL,
  `specialty_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `p_id` int(11) NOT NULL,
  `p_name` varchar(255) NOT NULL,
  `p_age` int(3) NOT NULL,
  `p_gender` varchar(10) NOT NULL,
  `p_contact` varchar(15) NOT NULL,
  `p_email` varchar(255) NOT NULL,
  `p_password` varchar(255) NOT NULL,
  `p_address` varchar(255) NOT NULL,
  `p_dob` date NOT NULL DEFAULT '2000-01-01',
  `p_type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`p_id`, `p_name`, `p_age`, `p_gender`, `p_contact`, `p_email`, `p_password`, `p_address`, `p_dob`, `p_type`) VALUES
(13, 'John Baloro', 25, 'Male', '09756027178', 'john@gmail.com', '$2y$10$IfBMQYvAqsNl.WUFSWS82eQxPsE2ymkpoycwSsXmmZF6yqRCY.g8O', 'United village', '2000-02-22', ''),
(14, 'hanz tan', 24, 'Male', '09786542172', 'hanz@gmail.com', '$2y$10$9Npa2ynUWp0jynSY4OtJZexXKD9mxIzd3vTW/3ooyTcND9RWMmQsm', 'patag', '2000-10-21', ''),
(15, 'payong donald', 21, 'Male', '09876573652', 'payong@gmail.com', '$2y$10$QRtpBP.BrSDOmdK07KiF7.1SiodRX2cRSnDbXOUmjk58FcxGtkaJq', 'carmen', '2004-02-20', ''),
(16, 'aiah salamanca', 26, 'Female', '09786587901', 'aiah@gmail.com', '$2y$10$wuMRHM3jjaMZYhdXm.0.NOL46RznfIGbhopdY9xAvFJsbtcnyaLlu', 'burgos', '1999-02-22', ''),
(17, 'kanzel baloro', 21, 'Male', '09789056472', 'kanzel@gmail.com', '$2y$10$SXZtqvIzLjj.vrkNlyr4S.gOz1xNHUPB42Dxv.LXjm6pr6gC5F3qy', 'agpa', '2003-03-24', ''),
(18, 'philip', 0, '', '', '', '', '', '2000-01-01', '');

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `sched_id` int(11) NOT NULL,
  `doc_id` int(11) NOT NULL,
  `sched_date` date DEFAULT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`sched_id`, `doc_id`, `sched_date`, `start_time`, `end_time`, `status`) VALUES
(1, 1, '0000-00-00', '09:00:00', '17:00:00', 'available'),
(2, 1, '0000-00-00', '09:00:00', '17:00:00', 'available'),
(3, 1, '0000-00-00', '09:00:00', '17:00:00', 'available'),
(4, 1, '0000-00-00', '09:00:00', '17:00:00', 'available'),
(5, 1, '0000-00-00', '09:00:00', '17:00:00', 'available'),
(6, 2, '0000-00-00', '10:00:00', '18:00:00', 'available'),
(7, 2, '0000-00-00', '10:00:00', '18:00:00', 'available'),
(8, 2, '0000-00-00', '10:00:00', '18:00:00', 'available'),
(9, 2, '0000-00-00', '10:00:00', '18:00:00', 'available'),
(10, 2, '0000-00-00', '10:00:00', '18:00:00', 'available'),
(11, 12, '2025-03-29', '15:00:00', '00:00:00', 'booked'),
(13, 8, '2025-04-15', '13:00:00', '00:00:00', 'booked'),
(15, 12, '2025-03-26', '14:30:00', '00:00:00', 'booked'),
(16, 12, '2025-04-04', '13:00:00', '00:00:00', 'booked'),
(17, 8, '2025-03-26', '13:26:00', '00:00:00', 'booked'),
(18, 12, '2025-03-27', '14:00:00', '00:00:00', 'booked'),
(19, 12, '2025-03-26', '13:11:00', '00:00:00', 'booked'),
(20, 10, '2025-03-20', '00:00:00', '00:00:00', 'available'),
(21, 12, '2025-03-20', '00:00:00', '00:00:00', 'available'),
(23, 12, '2025-03-27', '10:05:00', '00:00:00', 'available');

-- --------------------------------------------------------

--
-- Table structure for table `specialties`
--

CREATE TABLE `specialties` (
  `specialty_id` int(11) NOT NULL,
  `specialty_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `specialties`
--

INSERT INTO `specialties` (`specialty_id`, `specialty_name`) VALUES
(10, 'Dental Public Health'),
(4, 'Endodontics'),
(1, 'General Dentistry'),
(8, 'Oral Pathology'),
(9, 'Oral Radiology'),
(6, 'Oral Surgery'),
(2, 'Orthodontics'),
(7, 'Pediatric Dentistry'),
(3, 'Periodontics'),
(5, 'Prosthodontics');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','patient') NOT NULL DEFAULT 'patient'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `password`, `role`) VALUES
('', '', ''),
('Admin', 'admin123', 'patient'),
('aiah salamanca', '', ''),
('biboy@gmail.com', '$2y$10$W0sUYu8NVL0SIQLQxlH8LeRzyqzWiiL5Qtg0KYfcBF5Fx3CE.FYBG', 'patient'),
('cyrus tadoy', '', ''),
('doytads cyrus', '', ''),
('doytads tadoy', '', ''),
('hanz tan', '', ''),
('John Baloro', '', ''),
('John Philip Razo Baloro', '$2y$10$mok2wo8H1MYFYDS7mrFCe.g4Ieyd48ZnHow458Liff2fWhFp4Svcy', 'patient'),
('kanzel baloro', '', ''),
('payong donald', '', ''),
('philipbaloro@gmail.com', '$2y$10$xYxPf4./DHUrax1n157hJekvTjlIcQ/q3z3FUWYFV516Eu2XR4c9S', 'patient'),
('syrus tadoy', '', ''),
('von duma', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`aemail`);

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`app_id`),
  ADD KEY `p_id` (`p_id`),
  ADD KEY `doc_id` (`doc_id`),
  ADD KEY `sched_id` (`sched_id`);

--
-- Indexes for table `billing`
--
ALTER TABLE `billing`
  ADD PRIMARY KEY (`bill_id`),
  ADD KEY `app_id` (`app_id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`doc_id`),
  ADD KEY `fk_specialty` (`specialty_id`);

--
-- Indexes for table `doctor_specialties`
--
ALTER TABLE `doctor_specialties`
  ADD PRIMARY KEY (`id`),
  ADD KEY `doc_id` (`doc_id`),
  ADD KEY `specialty_id` (`specialty_id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`sched_id`),
  ADD KEY `doc_id` (`doc_id`);

--
-- Indexes for table `specialties`
--
ALTER TABLE `specialties`
  ADD PRIMARY KEY (`specialty_id`),
  ADD UNIQUE KEY `specialty_name` (`specialty_name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `app_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT for table `billing`
--
ALTER TABLE `billing`
  MODIFY `bill_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `doc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `doctor_specialties`
--
ALTER TABLE `doctor_specialties`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `sched_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `specialties`
--
ALTER TABLE `specialties`
  MODIFY `specialty_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`p_id`) REFERENCES `patients` (`p_id`),
  ADD CONSTRAINT `appointments_ibfk_2` FOREIGN KEY (`doc_id`) REFERENCES `doctors` (`doc_id`),
  ADD CONSTRAINT `appointments_ibfk_3` FOREIGN KEY (`sched_id`) REFERENCES `schedules` (`sched_id`);

--
-- Constraints for table `billing`
--
ALTER TABLE `billing`
  ADD CONSTRAINT `billing_ibfk_1` FOREIGN KEY (`app_id`) REFERENCES `appointments` (`app_id`) ON DELETE CASCADE;

--
-- Constraints for table `doctors`
--
ALTER TABLE `doctors`
  ADD CONSTRAINT `fk_specialty` FOREIGN KEY (`specialty_id`) REFERENCES `specialties` (`specialty_id`) ON DELETE CASCADE;

--
-- Constraints for table `doctor_specialties`
--
ALTER TABLE `doctor_specialties`
  ADD CONSTRAINT `doctor_specialties_ibfk_1` FOREIGN KEY (`doc_id`) REFERENCES `doctors` (`doc_id`),
  ADD CONSTRAINT `doctor_specialties_ibfk_2` FOREIGN KEY (`specialty_id`) REFERENCES `specialties` (`specialty_id`);

--
-- Constraints for table `schedules`
--
ALTER TABLE `schedules`
  ADD CONSTRAINT `schedules_ibfk_1` FOREIGN KEY (`doc_id`) REFERENCES `doctors` (`doc_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
